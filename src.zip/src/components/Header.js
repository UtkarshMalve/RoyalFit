import React from "react";
import { Link, useLocation } from "react-router-dom";

function Header() {
const location =useLocation();
const isadminDashboard = location.pathname==="/adminDashboard";

if(isadminDashboard){
  return null;
}

  return (
    <>
   <header>
      <nav className="navbar navbar-expand-lg navbar-transparent">
  <div className="container">
    <Link className="navbar-brand" to="/">
      ROYAL <span className="brand-highlight">FITNESS GYM</span>
    </Link>
    <button
      className="navbar-toggler"
      type="button"
      data-bs-toggle="collapse"
      data-bs-target="#navbarNav"
      aria-controls="navbarNav"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarNav">
      <ul className="navbar-nav ms-auto">
        <li className="nav-item">
          <Link className="nav-link" to="/">Home</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/gymDetails">About</Link>
        </li>
        <li className="nav-item dropdown">
          <Link
            className="nav-link dropdown-toggle"
            to="#"
            id="eventDropdown"  
            role="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            Events
          </Link>
          <ul className="dropdown-menu" aria-labelledby="eventDropdown">
            <li><Link className="dropdown-item" to="/gymBuddy">Buddy</Link></li>
            <li><Link className="dropdown-item" to="/gamificationPage">Gamification</Link></li>
            <li><Link className="dropdown-item" to="/dashboardEvent">Events</Link></li>
            <li><Link className="dropdown-item" to="/tracker">Running Tracker</Link></li>
          </ul>
        </li>
        <li className="nav-item dropdown">
          <Link
            className="nav-link dropdown-toggle"
            to="#"
            id="scheduleDropdown"
            role="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            Schedules
          </Link>
          <ul className="dropdown-menu" aria-labelledby="scheduleDropdown">
            <li><Link className="dropdown-item" to="/appointmentBooking">Appointment</Link></li>
            <li><Link className="dropdown-item" to="/dietPlans">Diet Plan</Link></li>
            <li><Link className="dropdown-item" to="/membershipDetails">Membership</Link></li>
            <li><Link className="dropdown-item" to="/chatVideoSelectionPage">Talk With Expert</Link></li>
          </ul>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/gallery">Gallery</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="#contact">Contact</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/feedbackFormPage">Feedback</Link>
        </li>
        <li className="nav-item">
          <Link className="btn btn-signup" to="/loginpage">Sign Up</Link>
        </li>
      </ul>
    </div>
  </div>
</nav>

    </header>
    </>

  );
}

export default Header;