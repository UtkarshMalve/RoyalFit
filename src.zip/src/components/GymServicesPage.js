import React from 'react';


const GymServicesPage = () => {
  return (
    <div className="gym-services">
      <h2 className="service-title">Our Gym Services</h2>
      <div className="services-container">
        <div className="service-card">
          <h3 className="service-name">Personal Training</h3>
          <p className="service-description">One-on-one sessions with expert trainers.</p>
        </div>
        <div className="service-card">
          <h3 className="service-name">Group Classes</h3>
          <p className="service-description">Join fun and motivating group workouts.</p>
        </div>
        <div className="service-card">
          <h3 className="service-name">Nutrition Counseling</h3>
          <p className="service-description">Get personalized nutrition plans and advice.</p>
        </div>
        <div className="service-card">
          <h3 className="service-name">Yoga & Meditation</h3>
          <p className="service-description">Relax and improve flexibility with expert-led sessions.</p>
        </div>
      </div>
    </div>
  );
};


export default GymServicesPage;


