import React from "react";
import Header from "./Header";

import Footer from "./Footer";
import { Outlet } from "react-router-dom";
import ChatBox from "./ChatBox";

function App() {
    return (
        <>
        <Header />
        <Outlet />
        <Footer />
        <ChatBox />

        </>
    );
}


export default App;