import React from 'react';
import video from '../assets/image/gym-video.mp4'
import img1 from '../assets/image/demo.jpg'
import img2 from '../assets/image/download1.jpg'

import { FaFacebook, FaTwitter, FaInstagram, FaGoogle,FaMapMarkerAlt } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';


const MainPage = () => {
  const navigate = useNavigate();

  const handleLearnMore = () => {
    navigate('/gymDetails');
  };
  return (<>
    <div className="main-banner" id="top">
      <video autoPlay muted loop id="bg-video">
        <source src={video} type="video/mp4" />
      </video>

      <div className="video-overlay header-text">
        <div className="caption" >
          <h6>work harder, get stronger</h6>
          <h2>
            easy with our <em>gym</em>
          </h2>
          <div className="main-button scroll-to-section">
            <a href="#features">Become a member</a>
          </div>
        </div>
      </div>
    </div>
   {/* ============================================================= */}

   <section className="choseus-section spad">
      <div className="container">
        <div className="row">
          <div className="col-lg-12">
            <div className="section-title">
              <span>Why choose us?</span>
              <h2>PUSH YOUR LIMITS FORWARD</h2>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-3 col-sm-6">
            <div className="cs-item">
              <span className="flaticon-034-stationary-bike"></span>
              <h4>Modern equipment</h4>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut dolore facilisis.
              </p>
            </div>
          </div>
          <div className="col-lg-3 col-sm-6">
            <div className="cs-item">
              <span className="flaticon-033-juice"></span>
              <h4>Healthy nutrition plan</h4>
              <p>
                Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.
              </p>
            </div>
          </div>
          <div className="col-lg-3 col-sm-6">
            <div className="cs-item">
              <span className="flaticon-019-bands"></span>
              <h4>Personal training</h4>
              <p>
                Scelerisque purus sit amet luctus venenatis lectus magna. Commodo nulla facilisi nullam vehicula.
              </p>
            </div>
          </div>
          <div className="col-lg-3 col-sm-6">
            <div className="cs-item">
              <span className="flaticon-037-medal"></span>
              <h4>Top-class instructors</h4>
              <p>
                Volutpat ac tincidunt vitae semper quis. Scelerisque purus sit amet luctus venenatis lectus magna.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>  

   
  {/* =============================================== */}
  <div className="container2">
  <section className="gymOwnerWrapper">
      <div className="gymOwnerContainer">
        <h2 className="gymOwnerTitle">Meet Our Gym Owner: <span className="gymOwnerName">[Owner's Name]</span></h2>
        <div className="gymOwnerFlex">
          <img 
            src={img1} 
            alt="Gym Owner" 
            className="gymOwnerImage animateZoomIn"
          />
          <div className="gymOwnerInfo animateFadeIn">
            <p className="gymOwnerTagline">🏋️ <strong>Passionate Leader, Fitness Enthusiast, Visionary</strong> 🏆</p>
            <p className="gymOwnerDescription">
              With a deep passion for health and fitness, <span className="gymOwnerName">[Owner's Name]</span> founded Paldes Fitness to create a community where everyone can achieve their wellness goals. Backed by years of experience, <span className="gymOwnerName">[Owner's Name]</span> is dedicated to providing a welcoming environment, cutting-edge facilities, and personalized support for every member.
            </p>
            <div className="gymOwnerMissionVision">
              <div>
                <h3 className="gymOwnerSubtitle">Our Mission</h3>
                <p className="gymOwnerText">"To inspire and empower individuals to lead healthier, happier lives through fitness."</p>
              </div>
              <div>
                <h3 className="gymOwnerSubtitle">Our Vision</h3>
                <p className="gymOwnerText">To be a leading fitness destination known for innovation, inclusivity, and exceptional member experiences.</p>
              </div>
            </div>
            <p className="gymOwnerNote">Let’s get fit together under the guidance of a leader who truly cares! 💪</p>
          </div>
        </div>
      </div>
    </section>
    </div>

    {/* ============================================================ */}

    <div className="team-container">
      <h2>Our Team</h2>
      <div className="team-grid">
        <div className="team-card">
          <img src={img2} alt="Josie Lane" />
          <h3>Josie Lane</h3>
          <p className="position">Job Position</p>
          <div className="team-social">
            <a href="#"><FaFacebook /></a>
            <a href="#"><FaTwitter /></a>
            <a href="#"><FaInstagram /></a>
          </div>
        </div>

        <div className="team-card">
          <img src={img2} alt="Martin Reed" />
          <h3>Martin Reed</h3>
          <p className="position">Job Position</p>
          <div className="team-social">
            <a href="#"><FaFacebook /></a>
            <a href="#"><FaTwitter /></a>
            <a href="#"><FaInstagram /></a>
          </div>
        </div>

        <div className="team-card">
          <img src={img2} alt="Candace Lee" />
          <h3>Candace Lee</h3>
          <p className="position">Job Position</p>
          <div className="team-social">
            <a href="#"><FaFacebook /></a>
            <a href="#"><FaTwitter /></a>
            <a href="#"><FaInstagram /></a>
          </div>
        </div>
      </div>
    </div>


    {/* ================================================================ */}
    {/* ================================================================ */}

    <div className="about-section">
      <div className="about-content">
        <h2 className="about-title">About Our Gym</h2>
        <p className="about-description">
          Transform your body, mind, and soul with us at Paldes Fitness. We offer cutting-edge equipment, world-class trainers, and a community that drives you to be your best every day. Let's embark on this journey together!
        </p>
        <button className="about-btn" onClick={handleLearnMore}>
          Learn More
        </button>
      </div>
    </div>

    {/* ================================================================ */}

    <div className="gym-services">
      <h2 className="service-title">Our Gym Services</h2>
      <div className="services-container">
        <div className="service-card">
          <h3 className="service-name">Personal Training</h3>
          <p className="service-description">One-on-one sessions with expert trainers.</p>
        </div>
        <div className="service-card">
          <h3 className="service-name">Group Classes</h3>
          <p className="service-description">Join fun and motivating group workouts.</p>
        </div>
        <div className="service-card">
          <h3 className="service-name">Nutrition Counseling</h3>
          <p className="service-description">Get personalized nutrition plans and advice.</p>
        </div>
        <div className="service-card">
          <h3 className="service-name">Yoga & Meditation</h3>
          <p className="service-description">Relax and improve flexibility with expert-led sessions.</p>
        </div>
      </div>
    </div>
    
    {/* ================================================================ */}



    {/* ============================================= */}

    <div className="contact-wrapper" id="contact">
      <div className="contact-content">
        {/* Left Section */}
        <div className="contact-left">
          <h2>Get In Touch</h2>
          <p>
            Whether you have a question or just want to say hello, we’d love to hear from you! 
            Reach out to us via social media or send us a message using the form.
          </p>

          <h3>Follow Us</h3>
          <div className="social-links">
            <a href="#" className="social-icon"><FaFacebook /></a>
            <a href="#" className="social-icon"><FaTwitter /></a>
            <a href="#" className="social-icon"><FaInstagram /></a>
            <a href="#" className="social-icon"><FaGoogle /></a>
          </div>

          <div className="map-wrapper">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3748.5797837403243!2d73.84246139999999!3d20.0261438!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bddc1df78551063%3A0xb8a2a380f9b92219!2sBharkadevi%20Icecream!5e0!3m2!1sen!2sin!4v1732815744241!5m2!1sen!2sin"
              width="100%" 
              height="100%" 
              style={{ border: '0' }} 
              loading="lazy" 
              allowFullScreen
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>

        {/* Right Section */}
        <div className="contact-right">
          <form>
            <h2>Contact Us</h2>
            <div className="form-control">
              <input type="text" placeholder="Your Name" required />
            </div>
            <div className="form-control">
              <input type="email" placeholder="Your Email" required />
            </div>
            <div className="form-control">
              <input type="text" placeholder="Your Phone Number" />
            </div>
            <div className="form-control">
              <textarea rows="5" placeholder="Your Message"></textarea>
            </div>
            <button type="submit" className="btn-submit">Send Message</button>
          </form>
        </div>
      </div>
    </div>



   
    </>
  );
};

export default MainPage;
