import React, { useState, useEffect } from "react";


const AppointmentBooking = () => {
  const [form, setForm] = useState({
    service: "",
    appointmentDate: "",
    appointmentTime: "",
    fullName: "",
    email: "",
    phone: "",
  });

  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      const response = await fetch("http://localhost:8712/api/appointments");
      const data = await response.json();
      setAppointments(data);
    } catch (error) {
      console.error("Error fetching appointments:", error);
    }
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch(
      "http://localhost:8712/api/appointments/book",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      }
    );

    if (response.ok) {
      alert("Appointment booked!");
      setForm({
        service: "",
        appointmentDate: "",
        appointmentTime: "",
        fullName: "",
        email: "",
        phone: "",
      });
      fetchAppointments();
    }
  };

  return (
    <div className="appointment-container">
      <h2 className="appointment-title">Book an Appointment</h2>
      <form className="appointment-form" onSubmit={handleSubmit}>
        <input
          className="appointment-input"
          name="fullName"
          placeholder="Full Name"
          value={form.fullName}
          onChange={handleChange}
          required
        />
        <input
          className="appointment-input"
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
        />
        <input
          className="appointment-input"
          type="tel"
          name="phone"
          placeholder="Phone"
          value={form.phone}
          onChange={handleChange}
          required
        />
        <select
          className="appointment-select"
          name="service"
          value={form.service}
          onChange={handleChange}
          required
        >
          <option value="">Select Service</option>
          <option value="Consultation">Consultation</option>
          <option value="Personal Training">Personal Training</option>
          <option value="Group Class">Group Class</option>
        </select>
        <input
          className="appointment-input"
          type="date"
          name="appointmentDate"
          value={form.appointmentDate}
          onChange={handleChange}
          required
        />
        <input
          className="appointment-input"
          type="time"
          name="appointmentTime"
          value={form.appointmentTime}
          onChange={handleChange}
          required
        />
        <button className="appointment-button" type="submit">
          Book Appointment
        </button>
      </form>

      <h2 className="appointment-title">My Appointments</h2>
      <div className="appointment-list">
        {appointments.map((app) => (
          <div key={app.id} className="appointment-card">
            <p className="appointment-service">
            <strong >Name:</strong> {app.fullName}
            </p>
            <p className="appointment-service">
              <strong>Service:</strong> {app.service}
            </p>
            <p className="appointment-date">
              <strong>Date:</strong> {app.appointmentDate} - {app.appointmentTime}
            </p>
            <p className="appointment-status">
              <strong>Status:</strong> {app.status}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AppointmentBooking;
