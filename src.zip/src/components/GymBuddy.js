import React, { useState } from 'react';

const GymBuddy = () => {
  const [buddies, setBuddies] = useState([
    { id: 1, name: 'John Doe', goal: 'Weight Loss', time: '08:00', intensity: 'Medium', available: true },
    { id: 2, name: 'Jane Smith', goal: 'Muscle Gain', time: '18:00', intensity: 'High', available: true },
    { id: 3, name: 'Mike Johnson', goal: 'Endurance', time: '12:00', intensity: 'Low', available: false },
  ]);

  const [filters, setFilters] = useState({ goal: '', time: '', intensity: '' });
  const [newBuddy, setNewBuddy] = useState({ name: '', goal: '', time: '', intensity: 'Medium', available: true });
  const [selectedBuddy, setSelectedBuddy] = useState(null);
  const [chatVisible, setChatVisible] = useState(false);
  const [messages, setMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');

  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handleNewBuddyChange = (e) => {
    setNewBuddy({ ...newBuddy, [e.target.name]: e.target.value });
  };

  const handleAddBuddy = (e) => {
    e.preventDefault();
    if (newBuddy.name && newBuddy.goal && newBuddy.time) {
      setBuddies([...buddies, { ...newBuddy, id: buddies.length + 1 }]);
      setNewBuddy({ name: '', goal: '', time: '', intensity: 'Medium', available: true });
    } else {
      alert('Please fill in all required fields.');
    }
  };

  const filteredBuddies = buddies.filter(
    (buddy) =>
      (!filters.goal || buddy.goal === filters.goal) &&
      (!filters.time || buddy.time === filters.time) &&
      (!filters.intensity || buddy.intensity === filters.intensity) &&
      buddy.available
  );

  const handleConnect = (buddy) => {
    setSelectedBuddy(buddy);
    setChatVisible(true);
    setMessages([]);
  };

  const handleSendMessage = () => {
    if (currentMessage.trim()) {
      setMessages((prevMessages) => [
        ...prevMessages,
        { sender: 'You', text: currentMessage.trim(), timestamp: new Date() },
      ]);
      setCurrentMessage('');
    }
  };

  const handleCloseChat = () => {
    setChatVisible(false);
    setSelectedBuddy(null);
  };

  return (
    <div className="gymbuddy-app">
      <header className="gymbuddy-header">
        <h1 className="gymbuddy-title">Gym Buddy Finder</h1>
      </header>

      <section className="gymbuddy-filters">
        <h2 className="gymbuddy-subtitle">Search Your Gym Buddy</h2>
        <div className="gymbuddy-filters-container">
          <select name="goal" onChange={handleFilterChange} className="gymbuddy-select">
            <option value="">Select Goal</option>
            <option value="Weight Loss">Weight Loss</option>
            <option value="Muscle Gain">Muscle Gain</option>
            <option value="Endurance">Endurance</option>
          </select>
          <input type="time" name="time" onChange={handleFilterChange} className="gymbuddy-time-input" />
          <select name="intensity" onChange={handleFilterChange} className="gymbuddy-select">
            <option value="">Select Intensity</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
        </div>
      </section>

      <section className="gymbuddy-add">
        <h2 className="gymbuddy-subtitle">Add New Gym Buddy</h2>
        <form className="gymbuddy-add-form" onSubmit={handleAddBuddy}>
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={newBuddy.name}
            onChange={handleNewBuddyChange}
            className="gymbuddy-input"
            required
          />
          <select
            name="goal"
            value={newBuddy.goal}
            onChange={handleNewBuddyChange}
            className="gymbuddy-select"
            required
          >
            <option value="">Select Goal</option>
            <option value="Weight Loss">Weight Loss</option>
            <option value="Muscle Gain">Muscle Gain</option>
            <option value="Endurance">Endurance</option>
          </select>
          <input
            type="time"
            name="time"
            value={newBuddy.time}
            onChange={handleNewBuddyChange}
            className="gymbuddy-time-input"
            required
          />
          <select
            name="intensity"
            value={newBuddy.intensity}
            onChange={handleNewBuddyChange}
            className="gymbuddy-select"
          >
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
          <button type="submit" className="gymbuddy-btn">Add Buddy</button>
        </form>
      </section>

      <section className="gymbuddy-list">
        <h2 className="gymbuddy-subtitle">Available Buddies</h2>
        <ul className="gymbuddy-list-container">
          {filteredBuddies.length ? (
            filteredBuddies.map((buddy) => (
              <li key={buddy.id} className="gymbuddy-item">
                <div className="gymbuddy-info">
                  <h3>{buddy.name}</h3>
                  <p>Goal: {buddy.goal}</p>
                  <p>Time: {buddy.time}</p>
                  <p>Intensity: {buddy.intensity}</p>
                </div>
                <button className="gymbuddy-connect-btn" onClick={() => handleConnect(buddy)}>
                  Connect
                </button>
              </li>
            ))
          ) : (
            <p>No buddies available for this search.</p>
          )}
        </ul>
      </section>

      {chatVisible && selectedBuddy && (
        <div className="gymbuddy-chat">
          <div className="gymbuddy-chat-header">
            <h3>Chat with {selectedBuddy.name}</h3>
            <button className="gymbuddy-close-btn" onClick={handleCloseChat}>×</button>
          </div>
          <div className="gymbuddy-chat-messages">
            {messages.map((msg, index) => (
              <div key={index} className="gymbuddy-chat-message">
                <strong>{msg.sender}:</strong> {msg.text}
              </div>
            ))}
          </div>
          <textarea
            className="gymbuddy-chat-input"
            placeholder="Type your message..."
            value={currentMessage}
            onChange={(e) => setCurrentMessage(e.target.value)}
          />
          <button className="gymbuddy-send-btn" onClick={handleSendMessage}>
            Send
          </button>
        </div>
      )}
    </div>
  );
};

export default GymBuddy;
