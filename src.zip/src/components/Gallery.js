import React from 'react'

export default function Gallery() {
  return (
    <div>
        <div className="app-container">
    {/* Header Section */}
    <header className="header-section">
      <div className="header-container">
        <h1 className="header-title">Gym Gallery</h1>
        <p className="header-subtitle">
          Take a look at our fitness facilities, equipment, and more!
        </p>
      </div>
    </header>

    {/* Gym Gallery Section */}
    <section className="gallery-section">
      <div className="row">
        <div className="col-12 col-md-4 mb-4">
          <div className="gallery-card">
            <img
              src="https://via.placeholder.com/500x300?text=Cardio+Area"
              alt="Gym Image 1"
              className="gallery-card-img"
            />
            <div className="gallery-card-body">
              <h5 className="gallery-card-title">Cardio Area</h5>
              <p className="gallery-card-text">
                Our cardio area is equipped with the latest machines to keep
                your heart healthy.
              </p>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4 mb-4">
          <div className="gallery-card">
            <img
              src="https://via.placeholder.com/500x300?text=Strength+Training"
              alt="Gym Image 2"
              className="gallery-card-img"
            />
            <div className="gallery-card-body">
              <h5 className="gallery-card-title">Strength Training</h5>
              <p className="gallery-card-text">
                Dedicated space for strength training with all the equipment you
                need to build muscle.
              </p>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4 mb-4">
          <div className="gallery-card">
            <img
              src="https://via.placeholder.com/500x300?text=Yoga+Area"
              alt="Gym Image 3"
              className="gallery-card-img"
            />
            <div className="gallery-card-body">
              <h5 className="gallery-card-title">Yoga & Stretching Area</h5>
              <p className="gallery-card-text">
                A peaceful area for yoga, stretching, and relaxation after your
                workout.
              </p>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4 mb-4">
          <div className="gallery-card">
            <img
              src="https://via.placeholder.com/500x300?text=Group+Classes"
              alt="Gym Image 4"
              className="gallery-card-img"
            />
            <div className="gallery-card-body">
              <h5 className="gallery-card-title">Group Classes</h5>
              <p className="gallery-card-text">
                Join our group classes for a fun and motivating workout
                experience with others.
              </p>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4 mb-4">
          <div className="gallery-card">
            <img
              src="https://via.placeholder.com/500x300?text=Free+Weights"
              alt="Gym Image 5"
              className="gallery-card-img"
            />
            <div className="gallery-card-body">
              <h5 className="gallery-card-title">Free Weights</h5>
              <p className="gallery-card-text">
                A dedicated section for free weights to enhance your strength
                training routine.
              </p>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4 mb-4">
          <div className="gallery-card">
            <img
              src="https://via.placeholder.com/500x300?text=Fitness+Lounge"
              alt="Gym Image 6"
              className="gallery-card-img"
            />
            <div className="gallery-card-body">
              <h5 className="gallery-card-title">Fitness Lounge</h5>
              <p className="gallery-card-text">
                Relax and refuel at our fitness lounge with healthy snacks and
                drinks.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
    </div>
  )
}
