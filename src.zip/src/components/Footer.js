import React from "react";
import { FaFacebook, FaTwitter, FaInstagram, FaGoogle } from 'react-icons/fa';


function Footer() {
  return (
    <>
     <footer className="footer bg-dark text-white py-4">
      <div className="container">
        <div className="row">
          {/* Left Section: Location & Contact */}
          <div className="col-md-4">
            <h5>LOCATION</h5>
            <p>123 Fitness St, Healthy City, IL 60604-2340</p>
            <h5>CONTACT</h5>
            <p>Email: info@paldesfitness.com</p>
            <p>Phone: +1 (234) 567-890</p>
          </div>

          {/* Center Section: Social Media Links */}
          <div className="col-md-4 text-center">
            <h5>FOLLOW US</h5>
            <div className="social-icons">
                <a href="#" className="social-icon"><FaFacebook /></a>
                <a href="#" className="social-icon"><FaTwitter /></a>
                <a href="#" className="social-icon"><FaInstagram /></a>
                <a href="#" className="social-icon"><FaGoogle /></a>
              </div>
             
            </div>
          

          {/* Right Section: Quick Links */}
          <div className="col-md-4 text-md-end">
            <h5>QUICK LINKS</h5>
            <ul className="list-unstyled">
              <li><a href="/about" className="text-white">About Us</a></li>
              <li><a href="/services" className="text-white">Services</a></li>
              <li><a href="/membership" className="text-white">Membership</a></li>
              <li><a href="/contact" className="text-white">Contact</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Section: Privacy Policy */}
        <div className="text-center mt-4">
          <p>&copy; 2024 Paldes Fitness. All rights reserved.</p>
          <p>
            <a href="/privacy-policy" className="text-white">Privacy Policy</a> | 
            <a href="/terms-of-service" className="text-white"> Terms of Service</a>
          </p>
        </div>
      </div>
    </footer>

    </>
  );
}

export default Footer;