import React, { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const AdminDashboard = () => {
 
  const [activeOption, setActiveOption] = useState("DashboardHome");
   const [fname, setFirstName] = useState("");
   const [lname, setLastName] = useState("");
   const [address, setAddress] = useState("");
   const [mobilenumber, setPhoneNumber] = useState("");
   const [email, setEmail] = useState("");
   const [username, setUserName] = useState("");
   const [password, setPassword] = useState("");
   const [role, setRole] = useState("Staff");
   const [plans, setPlans] = useState([]);
  const [form, setForm] = useState({ planName: "", duration: "", price: "" });
  const [classes, setClasses] = useState([]);
  const [newClass, setNewClass] = useState({ name: "", day: "", time: "" });
  const [editingClass, setEditingClass] = useState(null);
  const [events, setEvents] = useState([]);
  const [newEvent, setNewEvent] = useState({ name: "", date: "", time: "" });
  const [editEvent, setEditEvent] = useState(null);

  const handleChange = (e) => {
    setNewClass({ ...newClass, [e.target.name]: e.target.value });
    setForm({ ...form, [e.target.name]: e.target.value });
  };



  const handleSignOut = (event) => {
    event.preventDefault(); // Prevent form submission behavior
    alert("You have been signed out.");
    window.location.href = "/loginpage"; // Redirect to the login page
  };


 



  // ==========================================================================
  const [profile, setProfile] = useState({
    name: "Praduny Patil",
    email: "Praduny@example.com",
    mobile: "1234567890",
    aadhar: "1234-5678-9012",
    photo: "default-profile-photo-url.jpg", // Default photo URL
  });

  const [editedProfile, setEditedProfile] = useState({ ...profile });
  const [isEditing, setIsEditing] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedProfile({ ...editedProfile, [name]: value });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditedProfile({ ...editedProfile, photo: reader.result }); // Update photo in the editedProfile state
      };
      reader.readAsDataURL(file); // Read file as data URL (base64)
    }
  };

  const handleSave = () => {
    setProfile(editedProfile); // Save edited profile, including the new photo
    setIsEditing(false); // Exit editing mode
  };

  const handleCancel = () => {
    setEditedProfile({ ...profile }); // Reset to original profile
    setIsEditing(false); // Exit editing mode
  };
// ==========================================================================
// ==============================Membership plan============================================
useEffect(() => {
  fetch("http://localhost:8712/membership/all")
    .then((res) => res.json())
    .then((data) => setPlans(data));
}, []);



const addPlan = (e) => {
  e.preventDefault();
  fetch("http://localhost:8712/membership/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(form),
  })
    .then((res) => res.json())
    .then((newPlan) => setPlans([...plans, newPlan]));
};

const deletePlan = (id) => {
  fetch(`http://localhost:8712/membership/delete/${id}`, {
    method: "DELETE",
  }).then(() => setPlans(plans.filter((plan) => plan.id !== id)));
};


// ==============================Membership plan============================================



// ===========================Event ===============================================
 // Fetch all events
 useEffect(() => {
  fetch("https://localhost:7054/api/events/all")
    .then((response) => response.json())
    .then((data) => setEvents(data))
    .catch((error) => console.error("Error fetching events:", error));
}, []);

// Add new event
const handleAddEvent = () => {
  fetch("https://localhost:7054/api/events/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(newEvent),
  })
    .then((response) => response.json())
    .then((data) => {
      setEvents([...events, data]);
      setNewEvent({ name: "", date: "", time: "" });
    })
    .catch((error) => console.error("Error adding event:", error));
};

// Update event
const handleUpdateEvent = () => {
  fetch(`https://localhost:7054/api/events/update/${editEvent.id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(editEvent),
  })
    .then(() => {
      setEvents(events.map((event) => (event.id === editEvent.id ? editEvent : event)));
      setEditEvent(null);
    })
    .catch((error) => console.error("Error updating event:", error));
};

// Delete event
const handleDeleteEvent = (id) => {
  fetch(`https://localhost:7054/api/events/delete/${id}`, { method: "DELETE" })
    .then(() => setEvents(events.filter((event) => event.id !== id)))
    .catch((error) => console.error("Error deleting event:", error));
};

// =============================addevent=============================================


// ==============================ADD Classes============================================
useEffect(() => {
  fetchClasses();
}, []);

// ✅ Fetch all classes from API
const fetchClasses = async () => {
  try {
    const response = await fetch("https://localhost:7054/api/classes/all");
    if (!response.ok) {
      throw new Error("Failed to fetch classes");
    }
    const data = await response.json();
    setClasses(data);
  } catch (error) {
    console.error("Error fetching classes:", error);
  }
};

// ✅ Handle input change for add/edit form


// ✅ Add or Update Class
const handleSubmit = async (e) => {
  e.preventDefault();

  if (editingClass) {
    // Update Class
    try {
      const response = await fetch(
        `https://localhost:7054/api/classes/update/${editingClass.id}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newClass),
        }
      );

      if (response.ok) {
        alert("Class updated successfully!");
        setEditingClass(null);
        setNewClass({ name: "", day: "", time: "" });
        fetchClasses();
      } else {
        alert("Failed to update class.");
      }
    } catch (error) {
      console.error("Error updating class:", error);
    }
  } else {
    // Add Class
    try {
      const response = await fetch("https://localhost:7054/api/classes/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newClass),
      });

      if (response.ok) {
        alert("Class added successfully!");
        setNewClass({ name: "", day: "", time: "" });
        fetchClasses();
      } else {
        alert("Failed to add class.");
      }
    } catch (error) {
      console.error("Error adding class:", error);
    }
  }
};

// ✅ Edit Class
const handleEdit = (cls) => {
  setEditingClass(cls);
  setNewClass({ name: cls.name, day: cls.day, time: cls.time });
};

// ✅ Delete Class
const handleDelete = async (id) => {
  if (!window.confirm("Are you sure you want to delete this class?")) return;

  try {
    const response = await fetch(
      `https://localhost:7054/api/classes/delete/${id}`,
      { method: "DELETE" }
    );

    if (response.ok) {
      alert("Class deleted successfully!");
      fetchClasses();
    } else {
      alert("Failed to delete class.");
    }
  } catch (error) {
    console.error("Error deleting class:", error);
  }
};

// ===============================Add Classes===========================================

// ===============================Add notifications===========================================
const [notification, setNotification] = useState(""); // Input state
const handleAddNotification = async () => {
  if (notification) {
    // Add new notification to the backend
    await fetch("http://localhost:5000/api/notifications", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ notification }),
    });

    // Navigate back to NotificationsPage
    // navigate("/notificationsPage");
  }
};

// ===============================Add notifications===========================================

// ===============================Add Feedback===========================================

const [feedback, setFeedback] = useState(null);

useEffect(() => {
  // Assuming feedback is stored in localStorage, or you could fetch from a backend
  const storedFeedback = localStorage.getItem("userFeedback");
  if (storedFeedback) {
    setFeedback(JSON.parse(storedFeedback));
  }
}, []);

const renderStars = (rating) => {
  return (
    <div className="star-rating-result">
      {[1, 2, 3, 4, 5].map((star) => (
        <span key={star} className={rating >= star ? "star filled" : "star"}>
          &#9733;
        </span>
      ))}
    </div>
  );
};

if (!feedback) {
 
}
// ===============================Add Feedback===========================================
// ===============================Add appimant===========================================


  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    const response = await fetch("http://localhost:8712/api/appointments");
    const data = await response.json();
    setAppointments(data);
  };

  const updateStatus = async (id, status) => {
    await fetch(`http://localhost:8712/api/appointments/${id}/${status}`, { method: "PUT" });
    fetchAppointments();
  };

// ===============================Add appimant===========================================


// ===============================Staff registration===========================================



const onOptionChange = (e) => {
  setRole(e.target.value);
};

async function SignUp(e) {
  e.preventDefault();

  const userData = {
    FirstName: fname,
    LastName: lname,
    PhoneNo: mobilenumber,
    Email: email,
    Address: address,
    UserName: username,
    Password: password,
    Role: role,
  };

  try {
    const response = await fetch("https://localhost:7054/api/user/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: JSON.stringify(userData),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP error! ${errorText}`);
    }

    const result = await response.json();
    console.log("Success:", result);
    alert("Registration Successful!");
  } catch (error) {
    console.error("Error:", error);
    alert("Registration Failed! " + error.message);
  }
}


// ===============================Staff registration===========================================

  const renderContent = () => {
    switch (activeOption) {
      // ==========================================================================
      case "AdminProfile":
        
        return       <div className="admin-profile">
        <h2>Admin Profile</h2>
        <div className="profile-section">
          <img
            src={profile.photo} // Display the current profile photo (either default or uploaded)
            alt="Profile"
            className="profile-photo"
          />
          {!isEditing ? (
            <div className="profile-details">
              <p><strong>Name:</strong> {profile.name}</p>
              <p><strong>Email:</strong> {profile.email}</p>
              <p><strong>Mobile:</strong> {profile.mobile}</p>
              <p><strong>Aadhar:</strong> {profile.aadhar}</p>
              <div className="profile-buttons">
                <button className="btn btn-edit" onClick={() => setIsEditing(true)}>Edit Profile</button>
              </div>
            </div>
          ) : (
            <form className="edit-profile-form">
              <label>Name:</label>
              <input
                type="text"
                name="name"
                value={editedProfile.name}
                onChange={handleInputChange}
              />
              <label>Email:</label>
              <input
                type="email"
                name="email"
                value={editedProfile.email}
                onChange={handleInputChange}
              />
              <label>Mobile:</label>
              <input
                type="text"
                name="mobile"
                value={editedProfile.mobile}
                onChange={handleInputChange}
              />
              <label>Aadhar:</label>
              <input
                type="text"
                name="aadhar"
                value={editedProfile.aadhar}
                onChange={handleInputChange}
              />
              <label>Upload Profile Picture:</label>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
              />
              <div className="profile-buttons">
                <button
                  type="button"
                  className="btn btn-save"
                  onClick={handleSave}
                >
                  Save
                </button>
                <button
                  type="button"
                  className="btn btn-cancel"
                  onClick={handleCancel}
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

          // ==========================================================================
      case "Attendance":
        return <div><h3>Member Attendance</h3><p>Attendance details go here.</p></div>;
      case "PaymentStatus":
        return <div><h3>Payment Status</h3><p>Payment details go here.</p></div>;
      case "StaffDetails":
        return <div><h3>Staff Details</h3><p>Staff information goes here.</p></div>;
      case "MemberDetails":
        return <div><h3>Member Details</h3><p>Member information goes here.</p></div>;
      
      
      
      
      
        // ====================================================================================
      case "AddEvent":
        
        return <div>

<div className="admin-event-container">
      <h1>Manage Events</h1>

      {/* ✅ Add Event Form */}
      <div className="admin-event-form">
        <h3>Add Event</h3>
        <input
          type="text"
          placeholder="Event Name"
          value={newEvent.name}
          onChange={(e) => setNewEvent({ ...newEvent, name: e.target.value })}
        />
        <input
          type="date"
          value={newEvent.date}
          onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
        />
        <input
          type="time"
          value={newEvent.time}
          onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
        />
        <button onClick={handleAddEvent}>Add Event</button>
      </div>

      {/* ✅ Update Event Form */}
      {editEvent && (
        <div className="admin-event-form">
          <h3>Edit Event</h3>
          <input
            type="text"
            value={editEvent.name}
            onChange={(e) =>
              setEditEvent({ ...editEvent, name: e.target.value })
            }
          />
          <input
            type="date"
            value={editEvent.date}
            onChange={(e) =>
              setEditEvent({ ...editEvent, date: e.target.value })
            }
          />
          <input
            type="time"
            value={editEvent.time}
            onChange={(e) =>
              setEditEvent({ ...editEvent, time: e.target.value })
            }
          />
          <button onClick={handleUpdateEvent}>Update Event</button>
        </div>
      )}

      {/* ✅ Event List */}
      <div className="admin-event-list">
        <h3>Event List</h3>
        <ul>
          {events.map((event) => (
            <li key={event.id} className="admin-event-item">
              {event.name} - {event.date} {event.time}
              <button onClick={() => setEditEvent(event)}>Edit</button>
              <button onClick={() => handleDeleteEvent(event.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    </div>

        </div>;



         // ====================================================================================
      case "ContactMessages":
        return <div><h3>Contact Messages</h3><p>Messages from users go here.</p></div>;

      //=============================================================================================
      case "StaffRegistration":
        return (
          <div className="register-container">
      <div className="register-card">
        <h2 className="register-title">Register Here</h2>
        <form className="register-form" onSubmit={SignUp}>
          <label className="register-label">First Name:</label>
          <input type="text" className="register-input" value={fname} onChange={(e) => setFirstName(e.target.value)} required />

          <label className="register-label">Last Name:</label>
          <input type="text" className="register-input" value={lname} onChange={(e) => setLastName(e.target.value)} required />

          <label className="register-label">Address:</label>
          <input type="text" className="register-input" value={address} onChange={(e) => setAddress(e.target.value)} required />

          <label className="register-label">Phone Number:</label>
          <input type="tel" className="register-input" pattern="[0-9]{10}" value={mobilenumber} onChange={(e) => setPhoneNumber(e.target.value)} required />

          <label className="register-label">Email:</label>
          <input type="email" className="register-input" value={email} onChange={(e) => setEmail(e.target.value)} required />

          <label className="register-label">Username:</label>
          <input type="text" className="register-input" value={username} onChange={(e) => setUserName(e.target.value)} required />

          <label className="register-label">Password:</label>
          <input type="password" className="register-input" value={password} onChange={(e) => setPassword(e.target.value)} required />

          <div className="role-selection">
          
            <label className="role-option">
              <input type="radio" name="role" value="Staff" checked={role === "Staff"} onChange={onOptionChange} />
              Staff
            </label>
          
          </div>

          <button type="submit" className="register-button">Submit</button>
        </form>
      </div>
    </div>
        );
        

        //====================================================================================
      case "FeedbackMessages":
        return <div>
      <div className="feedback-container">
      <h1>Admin Feedback Dashboard</h1>
      <div className="feedback-details">
        <p><strong>Name:</strong> {feedback.name}</p>
        <p><strong>Email:</strong> {feedback.email}</p>
        <p><strong>Phone:</strong> {feedback.phone}</p>

        <div className="feedback-questions">
          <p><strong>Overall Gym Experience:</strong></p>
          {renderStars(feedback.question1Rating)}

          <p><strong>Trainer Satisfaction:</strong></p>
          {renderStars(feedback.question2Rating)}

          <p><strong>Gym Equipment Adequacy:</strong></p>
          {renderStars(feedback.question3Rating)}

          <p><strong>Environment Friendliness:</strong></p>
          {renderStars(feedback.question4Rating)}

          <p><strong>Recommend to Others:</strong></p>
          {renderStars(feedback.question5Rating)}
        </div>

        <p><strong>Additional Comments:</strong> {feedback.additionalComments || "No additional comments."}</p>
      </div>
    </div>





        </div>;

      //=============================================================================================
      case "AddClasses":
        return <div className="manage-classes-container">
        <h1>Manage Classes</h1>
  
        {/* ✅ Add / Update Class Form */}
        <div className="form-container">
          <h2>{editingClass ? "Edit Class" : "Add New Class"}</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="name"
              placeholder="Class Name"
              value={newClass.name}
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="day"
              placeholder="Day (e.g., Monday)"
              value={newClass.day}
              onChange={handleChange}
              required
            />
            <input
              type="Text"
              name="time"
               placeholder="hh:mm:ss"
              value={newClass.time}
              onChange={handleChange}
              required
            />
            <button type="submit" className="btn-save">
              {editingClass ? "Update Class" : "Add Class"}
            </button>
            {editingClass && (
              <button onClick={() => setEditingClass(null)} className="btn-cancel-edit">
                Cancel Edit
              </button>
            )}
          </form>
        </div>
  
        {/* ✅ Display Classes */}
        <h2>Classes Scheduled:</h2>
        <div className="class-list-container">
          {classes.length > 0 ? (
            <ul>
              {classes.map((cls) => (
                <li key={cls.id}>
                  <span>{cls.name} - {cls.day} {cls.time}</span>
                  <button onClick={() => handleEdit(cls)} className="btn-update">
                    Edit
                  </button>
                  <button onClick={() => handleDelete(cls.id)} className="btn-remove">
                    Delete
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p>No classes available</p>
          )}
        </div>
      
    
      {/* Back to ClassesPage */}
      <Link to="/classesPage" className="btn btn-secondaryaddclasses">
        Back to Classes
      </Link>
  

 




        </div>;



       //=================================================================================================
      case "AddNotification":
        return <div>
            <div className="add-notification-page">
      <h1>Add Notification</h1>

      <div className="add-notification-form">
        <input
          type="text"
          value={notification}
          onChange={(e) => setNotification(e.target.value)}
          placeholder="Enter notification message"
          className="notification-input"
        />
        <button onClick={handleAddNotification} className="btn btn-primary">
          Add Notification
        </button>
      </div>

      {/* Back to NotificationsPage */}
      <Link to="/notificationsPage" className="btn btn-secondary">
        Back to Notifications
      </Link>
    </div>





        </div>;








        //=======================================================================================
      case "AppointmentStatus":
        return <div className="admin-dashboard-container">
        <h2 className="admin-dashboard-title">Admin Dashboard</h2>
        <div className="admin-appointment-list">
          {appointments.map((app) => (
            <div key={app.id} className="admin-appointment-card">
              <p className="admin-appointment-name">
                <strong>Name:</strong> {app.fullName}
              </p>
              <p className="admin-appointment-service">
                <strong>Service:</strong> {app.service}
              </p>
              <p className="admin-appointment-date">
                <strong>Date:</strong> {app.appointmentDate} - {app.appointmentTime}
              </p>
              <p className={`admin-appointment-status status-${app.status.toLowerCase()}`}>
                <strong>Status:</strong> {app.status}
              </p>
  
              {app.status === "PENDING" && (
                <div className="admin-button-group">
                  <button
                    className="admin-button confirm"
                    onClick={() => updateStatus(app.id, "confirm")}
                  >
                    ✅ Confirm
                  </button>
                  <button
                    className="admin-button delete"
                    onClick={() => updateStatus(app.id, "delete")}
                  >
                    ❌ Delete
                  </button>
                </div>
              )}
  
              {app.status === "CONFIRMED" && (
                <button
                  className="admin-button delete"
                  onClick={() => updateStatus(app.id, "delete")}
                >
                  ❌ Delete
                </button>
              )}
            </div>
          ))}
        </div>
      </div>


        // =============================================================================
      case "MembershipPlans":
        return   <div className="membershipa-container">
        <h2 className="membershipa-title">Membership Plans</h2>
        <form className="membershipa-form" onSubmit={addPlan}>
          <input type="text" name="planName" placeholder="Plan Name" onChange={handleChange} required className="membership-input" />
          <input type="text" name="duration" placeholder="Duration" onChange={handleChange} required className="membership-input" />
          <input type="number" name="price" placeholder="Price" onChange={handleChange} required className="membership-input" />
          <button type="submit" className="membershipa-btn add-plan-btn">Add Plan</button>
        </form>
        <div className="membershipa-list">
          {plans.map((plan) => (
            <div key={plan.id} className="membershipa-card">
              <h3 className="membershipa-id">ID: {plan.id}</h3>
              <p className="membershipa-name">{plan.planName}</p>
              <p className="membershipa-duration">Duration: {plan.duration}</p>
              <p className="membershipa-price">Price: ${plan.price}</p>
              <button className="membershipa-btn delete-plan-btn" onClick={() => deletePlan(plan.id)}>Delete</button>
            </div>
          ))}
        </div>
      </div>;


        // ==========================================================================================
      
      case "ChatWithMember":
        return <div><h3>Chat with Members</h3><p>Chat interface goes here.</p></div>;
      default:
        return <div><h3>Welcome to the Admin Dashboard</h3><p>Select an option to view details.</p></div>;
    }
  };

  return (
    <>
      <nav className="navbar adminnavbar">
        <div className="container-fluid">
        <p><strong>Name:</strong> {profile.name}</p>
          <form className="d-flex" role="search">
            <button className="sign-out-btn" onClick={handleSignOut}>
              Sign Out
            </button>
          </form>
        </div>
      </nav>

      <div className="admin-dashboard">
        <div className="sidebar">
          <div className="admin-info">
            <img
              src={profile.photo} // Display the current profile photo (either default or uploaded
              alt="Admin Profile"
              className="admin-photo"
            />
             <p><strong>Email:</strong> {profile.email}</p>
          </div>
          <ul>
            <li onClick={() => setActiveOption("AdminProfile")}>Admin Profile</li>
            <li onClick={() => setActiveOption("Attendance")}>Attendance</li>
            <li onClick={() => setActiveOption("PaymentStatus")}>Payment Status</li>
            <li onClick={() => setActiveOption("StaffDetails")}>Staff Details</li>
            <li onClick={() => setActiveOption("MemberDetails")}>Member Details</li>
            <li onClick={() => setActiveOption("AddEvent")}>Add Event</li>
            <li onClick={() => setActiveOption("ContactMessages")}>Contact Messages</li>
            <li onClick={() => setActiveOption("StaffRegistration")}>Staff Registration</li>
            <li onClick={() => setActiveOption("FeedbackMessages")}>Feedback Messages</li>
            <li onClick={() => setActiveOption("AddClasses")}>Add Classes</li>
            <li onClick={() => setActiveOption("AddNotification")}>Add Notification</li>
            <li onClick={() => setActiveOption("AppointmentStatus")}>Appointment Status</li>
            <li onClick={() => setActiveOption("MembershipPlans")}>Membership Plans</li>
    
            <li onClick={() => setActiveOption("ChatWithMember")}>Chat with Members</li>
          </ul>
        </div>
        <div className="content">{renderContent()}</div>
      </div>
    </>
  );
};


export default AdminDashboard;
