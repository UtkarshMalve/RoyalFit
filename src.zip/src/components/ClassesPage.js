import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const ClassesPage = () => {
  const [classes, setClasses] = useState([]);

  useEffect(() => {
    fetchClasses();
  }, []);

  // ✅ Fetch all classes from API
  const fetchClasses = async () => {
    try {
      const response = await fetch("https://localhost:7054/api/Classes/all");
      if (!response.ok) {
        throw new Error("Failed to fetch classes");
      }
      const data = await response.json();
      setClasses(data);
    } catch (error) {
      console.error("Error fetching classes:", error);
    }
  };

  return (
    <div className="classes-page">
     

      {/* ✅ Display Classes */}
      <h1>Classes Scheduled:</h1>
      <div className="class-list">
        <ul>
          {classes.length > 0 ? (
            classes.map((cls) => (
              <li key={cls.id}>
                {cls.name} - {cls.day} {cls.time}
              </li>
            ))
          ) : (
            <p>No classes available</p>
          )}
        </ul>
      </div>

      {/* ✅ Back to Dashboard */}
      <Link to="/dashboardEvent" className="btn btn-secondary">
        Go Back to Dashboard
      </Link>
    </div>
  );
};

export default ClassesPage;
