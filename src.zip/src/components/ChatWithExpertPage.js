import React, { useState, useEffect, useRef } from 'react';

const ChatWithExpertPage = () => {
  const [messages, setMessages] = useState([
    { sender: 'Expert', text: 'Hi there! How can I assist you with your fitness journey today?' },
    { sender: 'User', text: 'I need guidance on my workout routine.' }
  ]);
  const [input, setInput] = useState('');
  const [image, setImage] = useState(null);
  const [selectedTopic, setSelectedTopic] = useState(null);
  const chatEndRef = useRef(null);

  const expertInfo = {
    name: 'Alex Fitness Coach',
    bio: 'Certified Fitness Trainer and Nutrition Expert',
    experience: '8+ years of experience in personal training and fitness coaching.',
    avatar: '💪'
  };

  const topics = [
    'Workout Routines',
    'Nutrition Plans',
    'Weight Loss Strategies',
    'Muscle Gain Techniques',
    'General Fitness Tips'
  ];

  const handleSendMessage = () => {
    if (input.trim()) {
      setMessages([...messages, { sender: 'User', text: input }]);
      setInput('');
    }
  };

  const handleEnterPress = (e) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      alert('Please upload a valid image file');
    }
  };

  const handleSendImage = () => {
    if (image) {
      setMessages([...messages, { sender: 'User', image }]);
      setImage(null);
    }
  };

  const handleBackToHome = () => {
    window.location.href = '/';
  };

  const handleSelectTopic = (topic) => {
    setSelectedTopic(topic);
    setMessages([
      ...messages,
      { sender: 'User', text: `I want to discuss ${topic}.` }
    ]);
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className='chatexpert'>
      <div className="chat-container">
        <div className="chat-header">
          <button className="back-button" onClick={handleBackToHome}>
            🏠 Back to Home
          </button>
          <div className="chat-header-info">
            <div className="chat-expert-avatar">{expertInfo.avatar}</div>
            <div className="chat-expert-details">
              <h3>{expertInfo.name}</h3>
              <p>{expertInfo.bio}</p>
              <p><strong>Experience:</strong> {expertInfo.experience}</p>
            </div>
          </div>
        </div>

        {/* Topic Selection */}
        {!selectedTopic && (
          <div className="topic-selection">
            <h3>Select a topic to chat about:</h3>
            <ul>
              {topics.map((topic, index) => (
                <li key={index} onClick={() => handleSelectTopic(topic)}>
                  {topic}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Chat Body */}
        {selectedTopic && (
          <div className="chat-body">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`chat-bubble ${msg.sender === 'User' ? 'user-message' : 'expert-message'}`}
              >
                {msg.text && <span className="chat-text">{msg.text}</span>}
                {msg.image && <img src={msg.image} alt="Uploaded" className="chat-image" />}
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
        )}

        {/* Chat Footer */}
        {selectedTopic && (
          <div className="chat-footer">
            <input
              type="text"
              className="chat-input"
              placeholder="Type a message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleEnterPress}
            />
            <button className="send-button" onClick={handleSendMessage}>
              ➤
            </button>

            <label htmlFor="image-upload" className="upload-button">
              📷
              <input
                id="image-upload"
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                style={{ display: 'none' }}
              />
            </label>

            {image && (
              <button className="send-button" onClick={handleSendImage}>
                Send Image
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatWithExpertPage;
