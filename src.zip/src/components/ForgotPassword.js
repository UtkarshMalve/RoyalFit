import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleForgotPassword = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("https://localhost:7054/api/users/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();
      if (response.ok) {
        setMessage(data.message);
      } else {
        setMessage(data);
      }
    } catch (error) {
      console.error("Error resetting password", error);
      setMessage("Failed to reset password.");
    }
  };

  return (
    <div className="forgot-password-container">
      <form className="forgot-password-form" onSubmit={handleForgotPassword}>
        <h2 className="forgot-password-title">Forgot Password?</h2>
        <p>Enter your email to receive a new password.</p>
        <input 
          className="input-field" 
          type="email" 
          placeholder="Enter your email" 
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          required 
        />
        <button className="btn-primary" type="submit">Reset Password</button>
        {message && <p className="message">{message}</p>}
      </form>
    </div>
  );
}
