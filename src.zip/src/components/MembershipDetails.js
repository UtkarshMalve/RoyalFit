import { useState, useEffect } from "react";

const MembershipDetails = () => {
  const [plans, setPlans] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8712/membership/all")
      .then((res) => res.json())
      .then((data) => setPlans(data));
  }, []);

  return (
    <div className="membership-container">
      <h2 className="membership-title">Membership Plans</h2>
      <div className="membership-list">
        {plans.map((plan) => (
          <div key={plan.id} className="membership-card">
            <h3 className="membership-plan-name">{plan.planName}</h3>
            <p className="membership-plan-duration">
              Duration: {plan.duration}
            </p>
            <p className="membership-plan-price">Price: ${plan.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MembershipDetails;
