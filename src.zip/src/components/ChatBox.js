import React, { useState } from "react";
import axios from "axios";


const ChatBox = () => {
  const [messages, setMessages] = useState([]);
  const [userMessage, setUserMessage] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const toggleChatBox = () => {
    setIsOpen(!isOpen);
  };

  const handleSendMessage = async () => {
    if (!userMessage.trim()) return;

    // Add the user's message to the messages array
    const newMessages = [
      ...messages,
      { sender: "user", text: userMessage },
    ];
    setMessages(newMessages); // Update state with the new user message

    setUserMessage(""); // Clear input after sending message

    try {
      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: "gpt-3.5-turbo",
          messages: [{ role: "user", content: userMessage }],
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer fake-api-key-for-testingBearer fake-api-key-for-testing`, // Replace with your OpenAI API key
          },
        }
      );

      const aiResponse = response.data.choices[0].message.content;
      setMessages([
        ...newMessages,
        { sender: "ai", text: aiResponse },
      ]); // Add AI's response to the messages array
    } catch (error) {
      setMessages([
        ...newMessages,
        { sender: "ai", text: "An error occurred. Please try again." },
      ]);
    }
  };

  return (
    <div className="chatContainer">
      <div className={`chatBox ${isOpen ? "open" : "closed"}`}>
        <div className="chatMessages">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`chatMessage ${msg.sender}`}
            >
              <p>{msg.text}</p>
            </div>
          ))}
        </div>
        <div className="chatInputArea">
          <input
            type="text"
            value={userMessage}
            onChange={(e) => setUserMessage(e.target.value)}
            placeholder="Type your message..."
            className="chatInput"
          />
          <button onClick={handleSendMessage} className="sendButton">
            Send
          </button>
        </div>
      </div>
      <div className="chatIcon" onClick={toggleChatBox}>
        💬
      </div>
    </div>
  );
};

export default ChatBox;
