import React, { useState, useEffect } from "react";
import Calendar from "react-calendar";
import { Link } from "react-router-dom";
import "react-calendar/dist/Calendar.css";

const EventsPage = () => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [events, setEvents] = useState([]);

  const formattedDate = selectedDate ? selectedDate.toISOString().split("T")[0] : "";

  useEffect(() => {
    if (formattedDate) {
      fetch(`https://localhost:7054/api/events/date/${formattedDate}`)
        .then((response) => response.json())
        .then((data) => setEvents(data))
        .catch((error) => console.error("Error fetching events:", error));
    }
  }, [formattedDate]);

  return (
    <div className="events-page-container">
      <h1 className="events-title">Events</h1>
      <p className="events-subtitle">Select a date to view events.</p>

      <div className="calendar-container">
        <Calendar onChange={setSelectedDate} className="custom-calendar" />
      </div>

      <div className="events-display-container">
        {formattedDate ? (
          <div className="events-list-container">
            <h3 className="events-list-title">Events on {formattedDate}</h3>
            {events.length > 0 ? (
              <ul className="events-list">
                {events.map((event) => (
                  <li key={event.id} className="event-item">
                    {event.name} - {event.time}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="no-events-message">No events on this day.</p>
            )}
          </div>
        ) : (
          <p className="select-date-message">Please select a date to view events.</p>
        )}
      </div>

      <Link to="/dashboardEvent" className="btn btn-secondary">
        ← Back to Dashboard
      </Link>
    </div>
  );
};

export default EventsPage;
