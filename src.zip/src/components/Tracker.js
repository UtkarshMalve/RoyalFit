// Import necessary libraries
import React, { useState, useEffect } from "react";
import GoogleMapReact from "google-map-react";

const Tracker = () => {
    const [isTracking, setIsTracking] = useState(false);
    const [steps, setSteps] = useState(0);
    const [position, setPosition] = useState({ lat: 0, lng: 0 });

    useEffect(() => {
        let stepInterval;

        if (isTracking) {
            stepInterval = setInterval(() => {
                setSteps((prevSteps) => prevSteps + 1);
            }, 1000);

            navigator.geolocation.watchPosition(
                (pos) => {
                    setPosition({
                        lat: pos.coords.latitude,
                        lng: pos.coords.longitude,
                    });
                },
                (err) => console.error(err),
                { enableHighAccuracy: true }
            );
        } else {
            clearInterval(stepInterval);
        }

        return () => clearInterval(stepInterval);
    }, [isTracking]);

    const handleStart = () => {
        setSteps(0);
        setIsTracking(true);
    };

    const handleStop = () => {
        setIsTracking(false);
    };

    return (
        <div className="tracker-container">
            <h1 className="tracker-title">Step & Direction Tracker</h1>
            <div className="tracker-buttons">
                <button className="tracker-button start-button" onClick={handleStart}>
                    Start
                </button>
                <button className="tracker-button stop-button" onClick={handleStop}>
                    Stop
                </button>
            </div>
            <div className="tracker-info">
                <p className="tracker-steps">Steps: {steps}</p>
            </div>
            <div className="tracker-map">
                <GoogleMapReact
                    bootstrapURLKeys={{ key: "FAKE_API_KEY_FOR_DEMO" }} // Replace this with your actual Google Maps API key
                    center={position}
                    zoom={15}
                >
                    <div
                        lat={position.lat}
                        lng={position.lng}
                        className="tracker-map-marker"
                    >
                        🚶
                    </div>
                </GoogleMapReact>
            </div>
        </div>
    );
};

export default Tracker;
