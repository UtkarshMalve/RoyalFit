import React, { useState } from 'react';


const StrengthChallenge = () => {
  const [repsCompleted, setRepsCompleted] = useState(0);
  const [goal, setGoal] = useState(50); // Example goal of 50 reps

  const handleCompleteReps = () => {
    if (repsCompleted < goal) {
      setRepsCompleted(repsCompleted + 1);
    }
  };

  return (
    <div className="strength-challenge">
      <h2>💪 Strength Challenge</h2>
      <p>Complete {goal} reps of your selected exercise!</p>
      <div className="progress">
        <span>
          {repsCompleted}/{goal} Reps Completed
        </span>
        <div
          className="progress-bar"
          style={{ width: `${(repsCompleted / goal) * 100}%` }}
        ></div>
      </div>
      <button onClick={handleCompleteReps} className="reps-button">
        Complete a Rep
      </button>
      {repsCompleted >= goal && <p className="success-message">🎉 Goal Achieved!</p>}
    </div>
  );
};

export default StrengthChallenge;
