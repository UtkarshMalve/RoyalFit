import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

const NotificationsPage = () => {
  const [notifications, setNotifications] = useState([]); // State for notifications

  // Fetch notifications from the backend
  useEffect(() => {
    const fetchNotifications = async () => {
      const response = await fetch("http://localhost:5000/api/notifications");
      const data = await response.json();
      setNotifications(data); // Update state with fetched notifications
    };

    fetchNotifications();
  }, []);

  return (
    <div className="notifications-page">
      <h1>Notifications</h1>
      <p>Stay updated with gym news and updates.</p>

      {/* Notifications List */}
      <ul>
        {notifications.map((notification, index) => (
          <li key={index}>{notification}</li>
        ))}
      </ul>

     
      <Link to="/dashboardEvent" className="btn btn-secondary">
        ← Back to Dashboard
      </Link>
    </div>
  );
};

export default NotificationsPage;
