import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const SelectMembershipPlan = () => {
  const [selectedPlan, setSelectedPlan] = useState(null);
  const navigate = useNavigate();  // Use useNavigate instead of useHistory

  const handlePlanSelect = (plan) => {
    setSelectedPlan(plan);
    // Navigate to the '/membership-details' route with the selected plan
    navigate('/membershipDetails', { state: { selectedPlan: plan } });
  };

  return (
    <div className='membershipage'>
    <section className="membership-container">
      <h2 className="membership-title">Select Your Membership Plan</h2>
      <div className="membership-options">
        {/* Monthly Plan */}
        <div className="membership-option">
          <h3 className="plan-title">Basic Plan</h3>
          <p className="plan-description">Access to gym equipment and group classes</p>
          <div className="plan-pricing">
            <p className="plan-price">$19.99/month</p>
            <p className="plan-price">or $50 for 3 months</p>
            <p className="plan-price">or $180 for 12 months</p>
          </div>
          <button onClick={() => handlePlanSelect('Basic Plan')} className="select-plan-button">
            Select Plan
          </button>
        </div>

        {/* 3-Month Plan */}
        <div className="membership-option">
          <h3 className="plan-title">Premium Plan</h3>
          <p className="plan-description">Includes Personal Training and Premium Classes</p>
          <div className="plan-pricing">
            <p className="plan-price">$39.99/month</p>
            <p className="plan-price">or $105 for 3 months</p>
            <p className="plan-price">or $390 for 12 months</p>
          </div>
          <button onClick={() => handlePlanSelect('Premium Plan')} className="select-plan-button">
            Select Plan
          </button>
        </div>

        {/* Yearly Plan */}
        <div className="membership-option">
          <h3 className="plan-title">Ultimate Plan</h3>
          <p className="plan-description">All-inclusive access, including nutrition consultations</p>
          <div className="plan-pricing">
            <p className="plan-price">$59.99/month</p>
            <p className="plan-price">or $160 for 3 months</p>
            <p className="plan-price">or $600 for 12 months</p>
          </div>
          <button onClick={() => handlePlanSelect('Ultimate Plan')} className="select-plan-button">
            Select Plan
          </button>
        </div>
      </div>
    </section>
    </div>
  );
};

export default SelectMembershipPlan;
