import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const FeedbackResultPage = () => {
  const [feedback, setFeedback] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedFeedback = localStorage.getItem("userFeedback");
    if (storedFeedback) {
      setFeedback(JSON.parse(storedFeedback));
    }
  }, []);

  if (!feedback) {
    return (
      <div className="feedback-result-container">
        <p className="feedback-message">No feedback submitted yet.</p>
        <button onClick={() => navigate("/feedback")} className="btn-go-back">
          Go Back to Feedback Form
        </button>
      </div>
    );
  }

  const renderStars = (rating) => (
    <div className="star-rating-result">
      {[1, 2, 3, 4, 5].map((star) => (
        <span key={star} className={rating >= star ? "star filled" : "star"}>
          &#9733;
        </span>
      ))}
    </div>
  );

  return (
    <div className="feedback-result-container">
      <h1 className="feedback-result-title">Feedback Summary</h1>
      <div className="feedback-details">
        <p><strong>Name:</strong> {feedback.name}</p>
        <p><strong>Email:</strong> {feedback.email}</p>
        <p><strong>Phone:</strong> {feedback.phone}</p>

        <div className="feedback-questions">
          <p><strong>Overall Gym Experience:</strong></p>
          {renderStars(feedback.question1Rating)}

          <p><strong>Trainer Satisfaction:</strong></p>
          {renderStars(feedback.question2Rating)}

          <p><strong>Gym Equipment Adequacy:</strong></p>
          {renderStars(feedback.question3Rating)}

          <p><strong>Environment Friendliness:</strong></p>
          {renderStars(feedback.question4Rating)}

          <p><strong>Recommend to Others:</strong></p>
          {renderStars(feedback.question5Rating)}
        </div>

        <p><strong>Additional Comments:</strong> {feedback.additionalComments || "No additional comments."}</p>
      </div>
      <button onClick={() => navigate("/")} className="btn-go-back">
        Go Back to Home
      </button>
    </div>
  );
};

export default FeedbackResultPage;
