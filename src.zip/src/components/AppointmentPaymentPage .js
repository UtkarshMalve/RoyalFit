import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const AppointmentPaymentPage = () => {
  const location = useLocation();
  const navigate = useNavigate();  // Use useNavigate instead of useHistory
  const { selectedPlan } = location.state;

  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    expirationDate: '',
    cvv: '',
    cardHolderName: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCardDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you would typically process the payment (e.g., via an API)
    alert('Payment Successful!');
    navigate('/confirmation');  // Use navigate instead of history.push
  };

  return (
    <section className="payment-container">
      <h2 className="payment-title">Payment for {selectedPlan}</h2>
      <form onSubmit={handleSubmit} className="payment-form">
        <div className="form-group">
          <label htmlFor="cardNumber">Card Number</label>
          <input
            type="text"
            id="cardNumber"
            name="cardNumber"
            placeholder="1234 5678 9876 5432"
            required
            value={cardDetails.cardNumber}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="expirationDate">Expiration Date</label>
          <input
            type="month"
            id="expirationDate"
            name="expirationDate"
            required
            value={cardDetails.expirationDate}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="cvv">CVV</label>
          <input
            type="text"
            id="cvv"
            name="cvv"
            placeholder="123"
            required
            value={cardDetails.cvv}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="cardHolderName">Cardholder Name</label>
          <input
            type="text"
            id="cardHolderName"
            name="cardHolderName"
            placeholder="John Doe"
            required
            value={cardDetails.cardHolderName}
            onChange={handleChange}
          />
        </div>
        <button type="submit" className="payment-button">Pay Now</button>
      </form>
    </section>
  );
};

export default AppointmentPaymentPage;
