import React from 'react';


const DietPlans = () => {
  return (
  <>
    {/* Hero Section */}
    <header className="diet-hero">
        <div className="diet-container">
          <h1 className="diet-title">Personalized Diet Plans</h1>
          <p className="diet-subtitle">
            Get your tailored diet plan to achieve your fitness goals effectively and healthily.
          </p>
        </div>
      </header>

      {/* Diet Plan Overview Section */}
      <section className="diet-overview">
        <div className="diet-row">
          <div className="diet-col-half">
            <h2 className="diet-overview-title">Why Follow a Diet Plan?</h2>
            <p className="diet-overview-text">
              A well-structured diet plan is crucial for reaching your fitness goals, whether it's weight loss, muscle gain, or improving your overall health. At Paldes Fitness, we provide personalized diet plans that suit your body type, lifestyle, and goals.
            </p>
          </div>
          <div className="diet-col-half">
            <img
              src="https://via.placeholder.com/500x300"
              alt="Healthy Food"
              className="diet-image"
            />
          </div>
        </div>
      </section>

      {/* Sample Diet Plans Section */}
      <section className="diet-sample-plans">
        <h2 className="diet-section-title">Sample Diet Plans</h2>
        <div className="diet-row">
          {/* Diet Plan 1 */}
          <div className="diet-col-third">
            <div className="diet-card">
              <img
                src="https://via.placeholder.com/300x200"
                className="diet-card-image"
                alt="Weight Loss Diet"
              />
              <div className="diet-card-body">
                <h5 className="diet-card-title">Weight Loss Diet</h5>
                <p className="diet-card-text">
                  A balanced diet plan designed to help you lose weight effectively, with low-calorie meals and high protein intake.
                </p>
                <a href="#" className="diet-button diet-button-success">
                  Learn More
                </a>
              </div>
            </div>
          </div>

          {/* Diet Plan 2 */}
          <div className="diet-col-third">
            <div className="diet-card">
              <img
                src="https://via.placeholder.com/300x200"
                className="diet-card-image"
                alt="Muscle Gain Diet"
              />
              <div className="diet-card-body">
                <h5 className="diet-card-title">Muscle Gain Diet</h5>
                <p className="diet-card-text">
                  A high-protein diet plan that focuses on muscle building with calorie surplus and nutrient-rich meals.
                </p>
                <a href="#" className="diet-button diet-button-success">
                  Learn More
                </a>
              </div>
            </div>
          </div>

          {/* Diet Plan 3 */}
          <div className="diet-col-third">
            <div className="diet-card">
              <img
                src="https://via.placeholder.com/300x200"
                className="diet-card-image"
                alt="General Fitness Diet"
              />
              <div className="diet-card-body">
                <h5 className="diet-card-title">General Fitness Diet</h5>
                <p className="diet-card-text">
                  A balanced diet for general fitness, focusing on maintaining good health and overall well-being with wholesome foods.
                </p>
                <a href="#" className="diet-button diet-button-success">
                  Learn More
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Diet Plan Consultation Section */}
      <section className="diet-consultation">
        <div className="diet-container">
          <h2 className="diet-section-title">Get a Personalized Diet Plan</h2>
          <p className="diet-text-center">
            Contact our expert nutritionists to get a diet plan tailored to your goals. We will help you choose the right foods to achieve optimal results in your fitness journey.
          </p>
          <div className="diet-text-center">
            <a href="contact.html" className="diet-button diet-button-primary">
              Contact Us
            </a>
          </div>
        </div>
      </section>
  
  </>
  );
};

export default DietPlans;
