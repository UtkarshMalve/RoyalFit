import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Fakeadditaments = () => {
  const [tips, setTips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTip, setSelectedTip] = useState(null);

  useEffect(() => {
    // Function to fetch the tips
    const fetchTips = async () => {
      const dateString = new Date().toISOString().split('T')[0]; // Get current date (yyyy-mm-dd)

      try {
        // Adding dateString to the URL to ensure the data changes every day
        const response = await axios.get(`https://jsonplaceholder.typicode.com/posts?_limit=5&_date=${dateString}`);
        setTips(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching the tips:", error);
        setLoading(false);
      }
    };

    fetchTips(); // Initial fetch
  }, []); // This will run once when the component is first mounted

  const handleClickTip = (tip) => {
    setSelectedTip(tip);
  };

  const handleCloseModal = () => {
    setSelectedTip(null);
  };

  return (
    <>
      {/* Sidebar Layout */}
      <div className="page-content">
        <div className="main-content">
          <section className="choseus-section spad">
            <div className="container">
              <h2>Explore Our Fitness Insights</h2>
              <p>Learn how to achieve your fitness goals with professional guidance.</p>
            </div>
          </section>
        </div>

        <aside className="sidebar">
          <div className="sidebar-widget">
            <h3>Latest Fitness Tips</h3>
            {loading ? (
              <p>Loading tips...</p>
            ) : (
              <ul className="tips-list">
                {tips.map((tip, index) => (
                  <li
                    key={tip.id}
                    className="tip-item"
                    onClick={() => handleClickTip(tip)}
                  >
                    <img
                      src={`https://picsum.photos/seed/${index + 1}/100/100`}
                      alt={`Tip ${index + 1}`}
                      className="tip-image"
                    />
                    <div className="tip-content">
                      <h4>{tip.title.slice(0, 20)}...</h4>
                      <p>{tip.body.slice(0, 70)}...</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </aside>
      </div>

      {/* Modal for detailed tip */}
      {selectedTip && (
        <div className="modal">
          <div className="modal-content">
            <h2>{selectedTip.title}</h2>
            <p>{selectedTip.body}</p>
            <button onClick={handleCloseModal}>Close</button>
          </div>
        </div>
      )}

      {/* Style Section */}
      <style jsx>{`
        .page-content {
          display: flex;
          gap: 20px;
          margin-top: 20px;
        }
        .main-content {
          flex: 3;
          padding-right: 20px;
        }
        .sidebar {
          flex: 1;
          background: #fff;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          padding: 20px;
          border-radius: 12px;
          overflow-y: auto;
          height: 400px;
        }
        .sidebar-widget h3 {
          font-size: 1.5em;
          margin-bottom: 15px;
          text-align: center;
          color: #444;
        }
        .tips-list {
          list-style: none;
          padding: 0;
        }
        .tip-item {
          display: flex;
          background: #f9f9f9;
          margin-bottom: 15px;
          padding: 10px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          transition: transform 0.2s;
          cursor: pointer;
        }
        .tip-item:hover {
          transform: scale(1.05);
        }
        .tip-image {
          border-radius: 8px;
          margin-right: 15px;
          flex-shrink: 0;
          width: 100px;
          height: 100px;
        }
        .tip-content h4 {
          margin: 0 0 5px;
          color: #0073e6;
          font-weight: bold;
        }
        .tip-content p {
          margin: 0;
          color: #666;
        }
        .modal {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          display: flex;
          justify-content: center;
          align-items: center;
        }
        .modal-content {
          background: white;
          padding: 20px;
          border-radius: 8px;
          width: 60%;
          max-width: 600px;
        }
        .modal-content h2 {
          margin-top: 0;
        }
        .modal-content button {
          padding: 10px 20px;
          background-color: #0073e6;
          color: white;
          border: none;
          border-radius: 5px;
          cursor: pointer;
        }
        .modal-content button:hover {
          background-color: #005bb5;
        }
        @media (max-width: 768px) {
          .page-content {
            flex-direction: column;
          }
          .sidebar {
            height: auto;
          }
        }
      `}</style>
    </>
  );
};

export default Fakeadditaments;
