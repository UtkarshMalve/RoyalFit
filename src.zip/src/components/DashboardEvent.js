import React from "react";
import { Link } from "react-router-dom";


const DashboardEvent = () => {
  const upcomingEvents = [
    { name: "Yoga Workshop", date: "15th November" },
    { name: "Fitness Challenge", date: "20th November" },
  ];

  const memberStats = {
    totalMembers: 120,
    activeMembers: 95,
    upcomingClasses: 10,
  };

  return (
    <div className="dashboard-container">
      <h1 className="dashboard-title">Welcome to Paldes Fitness</h1>

      <div className="row dashboard-cards">
        {/* Card for Classes */}
        <div className="col-lg-4 col-md-6 col-sm-12 mb-4">
          <div className="card card-classes">
            <div className="card-body ">
              <h5 className="card-title">Classes</h5>
              <p className="card-text">Book your fitness classes and stay fit.</p>
              <Link to="/classesPage" className="btn btn-light">View Classes</Link>
            </div>
          </div>
        </div>

        {/* Card for Events */}
        <div className="col-lg-4 col-md-6 col-sm-12 mb-4">
          <div className="card card-events">
            <div className="card-body">
              <h5 className="card-title">Events</h5>
              <p className="card-text">Join fitness events and challenges.</p>
              <Link to="/eventsPage" className="btn btn-light">View Events</Link>
            </div>
          </div>
        </div>

        {/* Card for Notifications */}
        <div className="col-lg-4 col-md-6 col-sm-12 mb-4">
          <div className="card card-notifications">
            <div className="card-body">
              <h5 className="card-title">Notifications</h5>
              <p className="card-text">Stay updated with gym news and updates.</p>
              <Link to="/notificationsPage" className="btn btn-light">View Notifications</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="row stats-container">
        {/* Member Stats */}
        <div className="col-md-6">
          <div className="card card-stats">
            <div className="card-body">
              <h5 className="card-title">Member Stats</h5>
              <p>Total Members: {memberStats.totalMembers}</p>
              <p>Active Members: {memberStats.activeMembers}</p>
              <p>Upcoming Classes: {memberStats.upcomingClasses}</p>
            </div>
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="col-md-6">
          <div className="card card-upcoming-events">
            <div className="card-body">
              <h5 className="card-title">Upcoming Events</h5>
              <ul>
                {upcomingEvents.map((event, index) => (
                  <li key={index}>{event.name} - {event.date}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardEvent;
