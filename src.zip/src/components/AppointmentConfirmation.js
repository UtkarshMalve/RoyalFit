import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';


const AppointmentConfirmation = () => {
  const { state } = useLocation();
  const navigate = useNavigate();

  return (
    <div className="appointment-success-container">
      <h2 className="appointment-title">Appointment Successfully Booked</h2>
      <div className="appointment-card">
        <div className="appointment-card-body">
          <h5>Your Appointment Details:</h5>
          <p><strong>Service:</strong> {state?.service}</p>
          <p><strong>Scheduled Date:</strong> {state?.appointmentDate}</p>
          <p><strong>Scheduled Time:</strong> {state?.appointmentTime}</p>
          <p><strong>Name:</strong> {state?.fullName}</p>
          <p><strong>Email:</strong> {state?.email}</p>
          <p><strong>Phone Number:</strong> {state?.phone}</p>
          <p className="success-message">We look forward to seeing you!</p>
        </div>
      </div>
      <div className="text-center mt-4">
        <button onClick={() => navigate('/')} className="btn-primary">
          Go to Home
        </button>
      </div>
    </div>
  );
};

export default AppointmentConfirmation;
