import React from 'react';


const GymDetails = () => {
  return (
    <div className="gym-details">
      <div className="details-header">
        <h1 className="details-title">Our Gym Services & Facilities</h1>
        <p className="details-description">
          At Paldes Fitness, we believe in delivering the best fitness experience through our cutting-edge facilities and expert trainers. Discover everything you need to transform your fitness journey.
        </p>
      </div>
      <div className="details-grid">
        <div className="details-card">
          <h2 className="card-title">State-of-the-art Equipment</h2>
          <p className="card-description">
            Experience top-tier equipment designed for all fitness levels, from beginners to pros.
          </p>
        </div>
        <div className="details-card">
          <h2 className="card-title">Personal Training Programs</h2>
          <p className="card-description">
            Customized training programs tailored to your fitness goals, guided by certified professionals.
          </p>
        </div>
        <div className="details-card">
          <h2 className="card-title">Group Fitness Classes</h2>
          <p className="card-description">
            Join fun, energetic group classes that keep you motivated and on track with your fitness goals.
          </p>
        </div>
        <div className="details-card">
          <h2 className="card-title">Yoga & Meditation Sessions</h2>
          <p className="card-description">
            Enhance your well-being with calming yoga and meditation classes for all levels.
          </p>
        </div>
        <div className="details-card">
          <h2 className="card-title">Nutrition & Diet Counseling</h2>
          <p className="card-description">
            Personalized diet plans and counseling to complement your workout routine.
          </p>
        </div>
        <div className="details-card">
          <h2 className="card-title">24/7 Access</h2>
          <p className="card-description">
            Enjoy round-the-clock access with our premium membership for maximum flexibility.
          </p>
        </div>
      </div>
      <button className="back-btn" onClick={() => window.history.back()}>Go Back</button>
    </div>
  );
};

export default GymDetails;
