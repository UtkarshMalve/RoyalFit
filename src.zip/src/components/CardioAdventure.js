import React, { useState, useEffect } from 'react';


const CardioAdventure = () => {
  const [distance, setDistance] = useState(0);
  const [goal, setGoal] = useState(5); // 5 km goal
  const [timer, setTimer] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      if (distance < goal) setTimer((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [distance, goal]);

  const handleRun = () => {
    if (distance < goal) setDistance(distance + 0.5); // Increase by 0.5 km per click
  };

  return (
    <div className="cardio-adventure">
      <h2>🏃‍♂️ Cardio Adventure</h2>
      <p>Run a total of {goal} km to complete the adventure!</p>
      <div className="distance-display">
        Distance: {distance.toFixed(1)} / {goal} km
      </div>
      <div className="timer-display">
        Time Elapsed: {Math.floor(timer / 60)}:{timer % 60 < 10 ? '0' : ''}
        {timer % 60} min
      </div>
      <button onClick={handleRun} className="run-button">
        Run +0.5 km
      </button>
      {distance >= goal && <p className="success-message">🎉 Adventure Complete!</p>}
    </div>
  );
};

export default CardioAdventure;
