import React, { useState } from 'react';
import StrengthChallenge from './StrengthChallenge';
import CardioAdventure from './CardioAdventure';


const GamificationPage = () => {
  const [selectedGame, setSelectedGame] = useState(null);

  return (
    <div className="gym-games">
      <h1>🏋️‍♂️ Gym Gamification Hub 🏆</h1>
      <div className="game-buttons">
        <button onClick={() => setSelectedGame('strength')} className="game-select-button">
          Strength Challenge
        </button>
        <button onClick={() => setSelectedGame('cardio')} className="game-select-button">
          Cardio Adventure
        </button>
      </div>
      <div className="game-container">
        {selectedGame === 'strength' && <StrengthChallenge />}
        {selectedGame === 'cardio' && <CardioAdventure />}
        {!selectedGame && <p>Select a game to begin!</p>}
      </div>
    </div>
  );
};



export default GamificationPage;
