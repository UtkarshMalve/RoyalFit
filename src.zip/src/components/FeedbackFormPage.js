import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // useNavigate instead of useHistory

const FeedbackFormPage = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    question1Rating: 0,
    question2Rating: 0,
    question3Rating: 0,
    question4Rating: 0,
    question5Rating: 0,
    additionalComments: "",
  });

  const navigate = useNavigate(); // Using useNavigate for navigation

  // Handle form field change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Handle star rating change for each question
  const handleRatingChange = (question, rating) => {
    setFormData({
      ...formData,
      [question]: rating,
    });
  };

  // Handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Save feedback locally (or to a server/database)
    localStorage.setItem("userFeedback", JSON.stringify(formData));

    // Navigate to the feedback display page after submission
    navigate("/feedbackResultPage"); // Navigate to the result page
  };

  // Render star rating for a question
  const renderStars = (question, rating) => {
    return (
      <div className="star-rating">
        {[1, 2, 3, 4, 5].map((star) => (
          <span
            key={star}
            className={rating >= star ? "star filled" : "star"}
            onClick={() => handleRatingChange(question, star)}
          >
            &#9733;
          </span>
        ))}
      </div>
    );
  };

  return (
    <div className="feedback-form-page">
      <div className="feedback-form-container">
        <h1 className="feedback-form-title">Submit Your Feedback</h1>
        <form onSubmit={handleSubmit} className="feedback-form">
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Your Name"
            required
            className="feedback-form-input"
          />

          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Your Email"
            required
            className="feedback-form-input"
          />

          <input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Your Phone Number"
            required
            className="feedback-form-input"
          />

          <div className="questions">
            <div className="question">
              <label className="question-label">How would you rate the overall gym experience?</label>
              <div className="rating-stars">{renderStars("question1Rating", formData.question1Rating)}</div>
            </div>
            <div className="question">
              <label className="question-label">How satisfied are you with the trainers?</label>
              <div className="rating-stars">{renderStars("question2Rating", formData.question2Rating)}</div>
            </div>
            <div className="question">
              <label className="question-label">Was the gym equipment adequate?</label>
              <div className="rating-stars">{renderStars("question3Rating", formData.question3Rating)}</div>
            </div>
            <div className="question">
              <label className="question-label">Did you find the gym environment welcoming?</label>
              <div className="rating-stars">{renderStars("question4Rating", formData.question4Rating)}</div>
            </div>
            <div className="question">
              <label className="question-label">Would you recommend the gym to others?</label>
              <div className="rating-stars">{renderStars("question5Rating", formData.question5Rating)}</div>
            </div>
          </div>

          <textarea
            name="additionalComments"
            value={formData.additionalComments}
            onChange={handleChange}
            placeholder="Any additional comments?"
            rows="4"
            className="feedback-form-textarea"
          />

          <button type="submit" className="btn-submit-feedback">
            Submit Feedback
          </button>
        </form>
      </div>
    </div>
  );
};

export default FeedbackFormPage;
