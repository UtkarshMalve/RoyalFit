import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";


const ResetPassword = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { email, tempPassword } = location.state || {};

  const [newPassword, setNewPassword] = useState("");
  const [enteredTempPassword, setEnteredTempPassword] = useState("");

  const handleResetPassword = async (event) => {
    event.preventDefault();

    if (!enteredTempPassword || !newPassword) {
      toast.error("All fields are required!");
      return;
    }

    if (enteredTempPassword !== tempPassword) {
      toast.error("Temporary password does not match!");
      return;
    }

    try {
      const response = await fetch(
        "https://localhost:7054/api/user/reset-password",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, oldPassword: tempPassword, newPassword }),
        }
      );

      if (!response.ok) throw new Error("Error resetting password.");

      toast.success("Password reset successful! Please login with your new password.");
      setTimeout(() => navigate("/"), 2000);
    } catch (error) {
      toast.error(error.message);
    }
  };

  return (
    <div className="reset-password-container">
      <ToastContainer position="bottom-center" />
      <div className="reset-password-box">
        <h2 className="reset-password-title">Reset Password</h2>

        <form className="reset-form" onSubmit={handleResetPassword}>
          <div className="reset-form-group">
            <label className="reset-label">Email:</label>
            <input className="reset-input" type="email" value={email} disabled />
          </div>

          <div className="reset-form-group">
            <label className="reset-label">Temporary Password:</label>
            <input
              className="reset-input"
              type="text"
              value={enteredTempPassword}
              onChange={(e) => setEnteredTempPassword(e.target.value)}
              required
            />
          </div>

          <div className="reset-form-group">
            <label className="reset-label">New Password:</label>
            <input
              className="reset-input"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
            />
          </div>

          <button className="reset-btn" type="submit">Change Password</button>
        </form>
      </div>
    </div>
  );
};

export default ResetPassword;
