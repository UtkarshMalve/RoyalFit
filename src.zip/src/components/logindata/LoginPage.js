import React from 'react';
import { useNavigate } from 'react-router-dom';


const LoginPage = () => {
  const navigate = useNavigate();

  return (
    <div className='main-loginpage'>
    <div className="login-page container text-center">
      <h2 className="login-title">Welcome! Please Select Your Role</h2>

      <div className="login-buttons">
        <button className="login-btn customer-btn" onClick={() => navigate('/memberlogin')}>
          Member Login
        </button>
        <button className="login-btn admin-btn" onClick={() => navigate('/staffLogin')}>
          Staff Login
        </button>
        <button className="login-btn agent-btn" onClick={() => navigate('/adminLogin')}>
          Admin Login
        </button>
      </div>
    </div>
    </div>
  );
};

export default LoginPage;
