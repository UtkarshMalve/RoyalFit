import React, { useState } from 'react';


const RegisterMember = () => {
  const [fname, setFirstName] = useState("");
  const [lname, setLastName] = useState("");
  const [address, setAddress] = useState("");
  const [mobilenumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("Member");

  const onOptionChange = (e) => {
    setRole(e.target.value);
  };

  async function SignUp(e) {
    e.preventDefault();

    const userData = {
      FirstName: fname,
      LastName: lname,
      PhoneNo: mobilenumber,
      Email: email,
      Address: address,
      UserName: username,
      Password: password,
      Role: role,
    };

    try {
      const response = await fetch("https://localhost:7054/api/user/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify(userData),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP error! ${errorText}`);
      }

      const result = await response.json();
      console.log("Success:", result);
      alert("Registration Successful!");
    } catch (error) {
      console.error("Error:", error);
      alert("Registration Failed! " + error.message);
    }
  }

  return (
    <div className="register-container">
      <div className="register-card">
        <h2 className="register-title">Register Here</h2>
        <form className="register-form" onSubmit={SignUp}>
          <label className="register-label">First Name:</label>
          <input type="text" className="register-input" value={fname} onChange={(e) => setFirstName(e.target.value)} required />

          <label className="register-label">Last Name:</label>
          <input type="text" className="register-input" value={lname} onChange={(e) => setLastName(e.target.value)} required />

          <label className="register-label">Address:</label>
          <input type="text" className="register-input" value={address} onChange={(e) => setAddress(e.target.value)} required />

          <label className="register-label">Phone Number:</label>
          <input type="tel" className="register-input" pattern="[0-9]{10}" value={mobilenumber} onChange={(e) => setPhoneNumber(e.target.value)} required />

          <label className="register-label">Email:</label>
          <input type="email" className="register-input" value={email} onChange={(e) => setEmail(e.target.value)} required />

          <label className="register-label">Username:</label>
          <input type="text" className="register-input" value={username} onChange={(e) => setUserName(e.target.value)} required />

          <label className="register-label">Password:</label>
          <input type="password" className="register-input" value={password} onChange={(e) => setPassword(e.target.value)} required />

          <div className="role-selection">
            <label className="role-option">
              <input type="radio" name="role" value="Member" checked={role === "Member"} onChange={onOptionChange} />
              Member
            </label>
           
          
          </div>

          <button type="submit" className="register-button">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default RegisterMember;
