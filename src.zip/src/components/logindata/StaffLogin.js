import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const StaffLogin = () => {
  const navigate = useNavigate();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Staff');
  const [showForgotPassword, setShowForgotPassword] = useState(false);

 

  const handleLogin = async (event) => {
    event.preventDefault();
  
    try {
      const response = await fetch('https://localhost:7054/api/user/login', {  
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username, password, role }),
      });
  
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      const result = await response.json();
      if (result.role !== 'Staff') {
        toast.error('Access Denied! Only Staff can log in.', { className: 'staff-toast-error' });
        return;
      }
  
      toast.success('Login Successful!', { className: 'staff-toast-success' });
  
      localStorage.setItem('username', username);
      setTimeout(() => navigate('/staffDashboard'), 1500);
  
    } catch (error) {
      toast.error(error.message, { className: 'staff-toast-error' });
    }
  };

   const handleForgotPassword = async () => {
      const email = prompt("Enter your registered email:");
  
      if (!email) {
        toast.error("Email is required!");
        return;
      }
  
      try {
        const response = await fetch(
          "https://localhost:7054/api/user/forgot-password",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email }),
          }
        );
  
        if (!response.ok) throw new Error("User not found or error occurred.");
  
        const result = await response.json();
        const tempPassword = result.tempPassword;
  
        const confirmRedirect = window.confirm(
          `Temporary Password: ${tempPassword}\n\nClick OK to reset your password.`
        );
  
        if (confirmRedirect) {
          navigate("/resetPassword", {
            state: { email, tempPassword },
          });
        }
      } catch (error) {
        toast.error(error.message);
      }
    };

  return (
    <div className="staff-login-container">
      <div className="staff-login-box">
        <h2 className="staff-login-title">Staff Login</h2>

        <form onSubmit={handleLogin}>
          <ToastContainer position="bottom-center" />
          
          <div className="staff-form-group">
            <label className="staff-form-label">Username:</label>
            <input
              type="text"
              className="staff-form-input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          
          <div className="staff-form-group">
            <label className="staff-form-label">Password:</label>
            <input
              type="password"
              className="staff-form-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="staff-login-button">Login</button>
        </form>

        <div className="staff-login-links">
      

          <p>
            Forgot password?{" "}
            <span onClick={handleForgotPassword}><button className="admin-login-btn">Reset Password</button></span>
          </p>

        </div>
      </div>
    </div>
  );
};

export default StaffLogin;
