import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const MemberLogin = () => {
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const response = await fetch("https://localhost:7054/api/user/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ username, password }),
      });

      if (!response.ok) throw new Error("Invalid username or password.");

      const result = await response.json();

      if (result.role !== "Member") {
        toast.error("Unauthorized Access! Only Members can log in.");
        return;
      }

      toast.success("Login Successful!");
      localStorage.setItem("username", username);
      localStorage.setItem("role", result.role);
      setTimeout(() => navigate("/memberDashboard"), 1500);
    } catch (error) {
      toast.error(error.message);
    }
  };

  const handleForgotPassword = async () => {
    const email = prompt("Enter your registered email:");

    if (!email) {
      toast.error("Email is required!");
      return;
    }

    try {
      const response = await fetch(
        "https://localhost:7054/api/user/forgot-password",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email }),
        }
      );

      if (!response.ok) throw new Error("User not found or error occurred.");

      const result = await response.json();
      const tempPassword = result.tempPassword;

      const confirmRedirect = window.confirm(
        `Temporary Password: ${tempPassword}\n\nClick OK to reset your password.`
      );

      if (confirmRedirect) {
        navigate("/resetPassword", {
          state: { email, tempPassword },
        });
      }
    } catch (error) {
      toast.error(error.message);
    }
  };
  const handleRegister = () => {
    navigate('/registerMember'); 
  };
  return (
    <div className="member-login-container">
      <ToastContainer position="bottom-center" />
      <div className="member-login-box">
        <h2>Member Login</h2>

        <form onSubmit={handleLogin}>
          <div className="member-form-group">
            <label>Username:</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className="member-form-group">
            <label>Password:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit"className="admin-login-btn">Login</button>
        </form>
        

        <div className="member-login-links">
          <br></br>
        <p>
            Don't have an account?{' '}
            <button onClick={handleRegister} className="staff-register-button">Register</button>
          </p>

        <p>
            Forgot password?{" "}
            <span onClick={handleForgotPassword}><button className="admin-login-btn">Reset Password</button></span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default MemberLogin;
