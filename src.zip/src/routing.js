import React from "react";
import { createBrowserRouter } from "react-router-dom";
import App from "./components/App";
import MainPage from "./components/MainPage";
import LoginPage from "./components/logindata/LoginPage";
import Gallery from "./components/Gallery";
import ForgotPassword from "./components/ForgotPassword";
import SignUpPage from "./components/SignUpPage";
import DietPlans from "./components/DietPlans";
import AppointmentBooking from "./components/AppointmentBooking";
import AppointmentConfirmation from "./components/AppointmentConfirmation";
import SelectMembershipPlan from "./components/SelectMembershipPlan";
import MembershipDetails from "./components/MembershipDetails";
import DashboardEvent from "./components/DashboardEvent";
import AppointmentPaymentPage from "./components/AppointmentPaymentPage ";
import ClassesPage from "./components/ClassesPage";
import EventsPage from "./components/EventsPage";
import NotificationsPage from "./components/NotificationsPage";
import FeedbackFormPage from "./components/FeedbackFormPage";
import FeedbackResultPage from "./components/FeedbackResultPage";
import ChatBox from "./components/ChatBox";
import GamificationPage from "./components/GamificationPage";
import GymBuddy from "./components/GymBuddy";
import GymDetails from "./components/GymDetails";
import ChatWithExpertPage from "./components/ChatWithExpertPage";
import AdminDashboard from "./components/AdminDashboard/AdminDashboard";
import AdminLogin from "./components/logindata/AdminLogin";
import ResetPassword from "./components/logindata/ResetPassword";
import RegisterMember from "./components/logindata/RegisterMember";
import StaffLogin from "./components/logindata/StaffLogin";
import Memberlogin from "./components/logindata/Memberlogin";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "/",
        element: <MainPage />,
      },
      {
        path: "/loginpage",
        element: <LoginPage />,
      },
      {
        path: "/gallery",
        element: <Gallery />,
      },
      {
        path: "/forgotPassword",
        element: <ForgotPassword />,
      },
    
      {
        path: "/SignUpPage",
        element: <SignUpPage/>,
      },
      {
        path: "/dietPlans",
        element: <DietPlans/>,
      },
      {
        path: "/appointmentBooking",
        element: <AppointmentBooking/>,
      },
      {
        path: "/appointmentConfirmation",
        element: <AppointmentConfirmation/>,
      },
   
      {
        path: "/membershipDetails",
        element: <MembershipDetails/>,
      },
      {
        path: "/appointmentPaymentPage",
        element: <AppointmentPaymentPage/>,
      },
      {
        path: "/dashboardEvent",
        element: <DashboardEvent/>,
      },
      {
        path: "/classesPage",
        element: <ClassesPage/>,
      },
      {
        path: "/eventsPage",
        element: <EventsPage/>,
      },
      {
        path: "/notificationsPage",
        element: <NotificationsPage/>,
      },
      {
        path: "/feedbackFormPage",
        element: <FeedbackFormPage/>,
      },
      {
        path: "/feedbackResultPage",
        element: <FeedbackResultPage/>,
      },
      {
        path: "/chatBox",
        element: <ChatBox/>,
      },
      {
        path: "/gamificationPage",
        element: <GamificationPage/>,
      },
      {
        path: "/gymBuddy",
        element: <GymBuddy/>,
      },
      {
        path: "/gymDetails",
        element: <GymDetails/>,
      },
  
      {
        path: "/chatVideoSelectionPage",
        element: <ChatWithExpertPage/>,
      },
  
      {
        path: "/adminDashboard",
        element: <AdminDashboard/>,
      },
      
      
      {
        path: "/adminLogin",
        element: <AdminLogin/>,
      },
      {
        path: "/resetPassword",
        element: <ResetPassword/>,
      },
    
      {
        path: "/registerMember",
        element: <RegisterMember/>,
      },
    
      {
        path: "/staffLogin",
        element: <StaffLogin/>,
      },
      {
        path: "/memberlogin",
        element: <Memberlogin/>,
      },
      {
        path: "/resetPassword",
        element: <ResetPassword/>,
      },
    
    
  
      
    
    
      
    ],
  },
]);


export default router;

