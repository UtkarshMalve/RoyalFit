package com.example.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;  // ✅ Correct Import
import org.springframework.stereotype.Service;
import com.example.Entity.Appointment;
import com.example.repository.AppointmentRepository;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository repository;

    public Appointment bookAppointment(Appointment appointment) {
        appointment.setStatus(Appointment.Status.PENDING); // Default status is Pending
        return repository.save(appointment);
    }

    public List<Appointment> getAllAppointmentsSorted() {
        return repository.findAll(Sort.by(Sort.Direction.DESC, "id"));  // ✅ Correct Sorting Syntax
    }

    public Appointment updateStatus(Long id, Appointment.Status status) {
        Appointment appointment = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
        appointment.setStatus(status);
        return repository.save(appointment);
    }
}
