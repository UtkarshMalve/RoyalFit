package com.example.repository;

import java.util.List;
import org.springframework.data.domain.Sort; // ✅ Correct import
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Entity.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findAll(Sort sort);  // ✅ Custom sorted query
}
