package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.Entity.Appointment;
import com.example.service.AppointmentService;
import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = "*") // ✅ Allow all origins (for testing)
public class AppointmentController {

    @Autowired
    private AppointmentService service;

    @PostMapping("/book")
    public Appointment bookAppointment(@RequestBody Appointment appointment) {
        return service.bookAppointment(appointment);
    }

    @GetMapping
    public List<Appointment> getAllAppointments() {
        return service.getAllAppointmentsSorted();  // ✅ Calls the sorted method
    }

    @PutMapping("/{id}/confirm")
    public Appointment confirmAppointment(@PathVariable Long id) {
        return service.updateStatus(id, Appointment.Status.CONFIRMED);
    }

    @PutMapping("/{id}/delete")
    public Appointment deleteAppointment(@PathVariable Long id) {
        return service.updateStatus(id, Appointment.Status.DELETED);
    }
}
