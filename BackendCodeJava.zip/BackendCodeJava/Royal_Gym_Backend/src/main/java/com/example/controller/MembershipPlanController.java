package com.example.controller;

import com.example.Entity.MembershipPlan;
import com.example.service.MembershipPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/membership")
@CrossOrigin(origins = "*")
public class MembershipPlanController {

    @Autowired
    private MembershipPlanService service;

    @PostMapping("/add")
    public MembershipPlan addPlan(@RequestBody MembershipPlan plan) {
        return service.addPlan(plan);
    }

    @GetMapping("/all")
    public List<MembershipPlan> getAllPlans() {
        return service.getAllPlans();
    }

    @GetMapping("/{id}")
    public Optional<MembershipPlan> getPlanById(@PathVariable Long id) {
        return service.getPlanById(id);
    }

    @DeleteMapping("/delete/{id}")
    public String deletePlan(@PathVariable Long id) {
        service.deletePlan(id);
        return "Membership Plan Deleted Successfully!";
    }
}
