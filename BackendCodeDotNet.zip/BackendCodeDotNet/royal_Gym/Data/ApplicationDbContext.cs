﻿// Database Context (ApplicationDbContext.cs)
using Microsoft.EntityFrameworkCore;
using GymManagementAPI.Models;
using royal_gym.Models;

namespace GymManagementAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique(); // Ensures unique email

            // ✅ Ensure Event Date is Required
            modelBuilder.Entity<Event>()
                .Property(e => e.Date)
                .IsRequired();

            modelBuilder.Entity<Class>().ToTable("Classes");

            modelBuilder.Entity<Notification>()
              .Property(n => n.CreatedAt)
              .HasDefaultValueSql("GETUTCDATE()");
        }
        public DbSet<User> Users { get; set; }
        public DbSet<Class> Classes { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Notification> Notifications { get; set; } // ✅ Added Notifications
    }
}