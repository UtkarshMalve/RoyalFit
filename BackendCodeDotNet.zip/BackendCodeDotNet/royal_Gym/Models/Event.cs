﻿using System.ComponentModel.DataAnnotations;

namespace royal_gym.Models
{
    public class Event
    {
        [Key]  // Ensure there is a primary key
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public DateTime Date { get; set; }


    }
}
