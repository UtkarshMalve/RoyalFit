﻿using System.ComponentModel.DataAnnotations;


namespace royal_gym.Models
{
    public class Class
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }  // Example: Yoga, Pilates

        [Required]
        public string Day { get; set; }  // Example: Monday

        [Required]
        public TimeSpan Time { get; set; }  // Example: 06:00 AM
    }
}
