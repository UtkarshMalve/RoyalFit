﻿using GymManagementAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using royal_gym.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace royal_gym.Controllers
{
    [Route("api/classes")]
    [ApiController]
    public class ClassesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ClassesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ GET: api/classes/all → Retrieve all classes
        [HttpGet("all")]
        public async Task<ActionResult<IEnumerable<Class>>> GetAllClasses()
        {
            return await _context.Classes.ToListAsync();
        }

        // ✅ GET: api/classes/{id} → Retrieve a specific class by ID
        [HttpGet("get/{id}")]
        public async Task<ActionResult<Class>> GetClassById(int id)
        {
            var classItem = await _context.Classes.FindAsync(id);
            if (classItem == null)
            {
                return NotFound();
            }
            return classItem;
        }

        // ✅ POST: api/classes/add → Create a new class
        [HttpPost("add")]
        public async Task<IActionResult> AddClass([FromBody] Class classItem)
        {
            if (classItem == null || string.IsNullOrWhiteSpace(classItem.Name) || string.IsNullOrWhiteSpace(classItem.Day))
            {
                return BadRequest(new { message = "Invalid class data." });
            }

            try
            {
                _context.Classes.Add(classItem);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetClassById), new { id = classItem.Id }, classItem);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error saving class.", error = ex.Message });
            }
        }



        // ✅ PUT: api/classes/update/{id} → Update an existing class
        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateClass(int id, [FromBody] Class classItem)
        {
            var existingClass = await _context.Classes.FindAsync(id);
            if (existingClass == null)
            {
                return NotFound("Class not found.");
            }

            existingClass.Name = classItem.Name;
            existingClass.Day = classItem.Day;
            existingClass.Time = classItem.Time;

            await _context.SaveChangesAsync();
            return Ok(existingClass);
        }

        // ✅ DELETE: api/classes/delete/{id} → Delete a class
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteClass(int id)
        {
            var classItem = await _context.Classes.FindAsync(id);
            if (classItem == null)
            {
                return NotFound("Class not found.");
            }

            _context.Classes.Remove(classItem);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
