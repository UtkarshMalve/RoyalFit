﻿using GymManagementAPI.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using royal_gym.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;



namespace royal_gym.Controllers
{
    [Route("api/events")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public EventsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ Get all events
        [HttpGet("all")]
        public async Task<IActionResult> GetAllEvents()
        {
            var events = await _context.Events.ToListAsync();
            return Ok(events);
        }

        // ✅ Get events by date
        [HttpGet("date/{date}")]
        public async Task<IActionResult> GetEventsByDate(DateTime date)
        {
            var events = await _context.Events
                .Where(e => e.Date.Date == date.Date)
               .ToListAsync();

            if (!events.Any())
                return NotFound(new { message = "No events found for the selected date." });

            return Ok(events);
        }

        // ✅ Get a single event by ID
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetEventById(int id)
        {
            var eventItem = await _context.Events.FindAsync(id);
            if (eventItem == null)
                return NotFound(new { message = "Event not found." });

            return Ok(eventItem);
        }

        // ✅ Add a new event
        [HttpPost("add")]
        public async Task<IActionResult> AddEvent([FromBody] Event newEvent)
        {
            if (newEvent == null)
                return BadRequest(new { message = "Invalid event data." });

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEventById), new { id = newEvent.Id }, newEvent);
        }

        // ✅ Update an existing event
        [HttpPut("update/{id:int}")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] Event updatedEvent)
        {
            if (id != updatedEvent.Id)
                return BadRequest(new { message = "Event ID mismatch." });

            var existingEvent = await _context.Events.FindAsync(id);
            if (existingEvent == null)
                return NotFound(new { message = "Event not found." });

            existingEvent.Name = updatedEvent.Name;
            existingEvent.Date = updatedEvent.Date;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Event updated successfully." });
        }

        // ✅ Delete an event
        [HttpDelete("delete/{id:int}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var eventItem = await _context.Events.FindAsync(id);
            if (eventItem == null)
                return NotFound(new { message = "Event not found." });

            _context.Events.Remove(eventItem);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Event deleted successfully." });
        }
    }
}
